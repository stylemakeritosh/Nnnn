const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const balancePath = './Balance.json';
const invPath = './inventory.json';
const cdPath = './cdrob.json';
const emoji = '<:0_Deco_stargold:1363095379364679881>';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('rob')
    .setDescription('Attempt to steal 25% of a user\'s Thunder Coins (10m cooldown)')
    .addUserOption(option =>
      option.setName('user').setDescription('User to rob').setRequired(true)
    ),

  async execute(interaction) {
    try {
      const target = interaction.options.getUser('user');
      if (target.id === interaction.user.id) {
        return interaction.reply({ content: 'You cannot rob yourself!', ephemeral: true });
      }

      let balanceData = JSON.parse(fs.readFileSync(balancePath, 'utf8'));
      let invData = fs.existsSync(invPath) ? JSON.parse(fs.readFileSync(invPath, 'utf8')) : {};
      let cdData = fs.existsSync(cdPath) ? JSON.parse(fs.readFileSync(cdPath, 'utf8')) : {};

      const userBalance = balanceData[interaction.user.id] ?? 0;
      const targetBalance = balanceData[target.id] ?? 0;
      if (userBalance === 0) {
        return interaction.reply({ content: 'You have no Thunder Coins to risk!', ephemeral: true });
      }
      if (targetBalance === 0) {
        return interaction.reply({ content: `${target.username} has no Thunder Coins to steal!`, ephemeral: true });
      }

      const now = Date.now();
      const exemptUserId = '1029672039604289566';
      if (interaction.user.id !== exemptUserId) {
        const cooldown = 10 * 60 * 1000; // 10 minutes
        const lastRob = cdData[interaction.user.id] || 0;
        if (now - lastRob < cooldown) {
          const timeLeft = cooldown - (now - lastRob);
          const minutes = Math.floor(timeLeft / 60000);
          const seconds = Math.floor((timeLeft % 60000) / 1000);
          return interaction.reply({
            content: `You're on cooldown! Try again in **${minutes}m ${seconds}s**.`,
            ephemeral: true,
          });
        }
      }

      let robChance = 0.10; // Base 10% chance
      const userInv = invData[interaction.user.id] || {};
      const targetInv = invData[target.id] || {};
      const anriControlCount = userInv['Anri Control'] || 0;
      const hasGimmeM = userInv['Gimme... M'] || 0;
      const aikuDefenseCount = targetInv['Aiku Defense'] || 0;

      robChance += anriControlCount * 0.08; // +8% per Anri Control
      if (hasGimmeM > 0) robChance += 0.15; // +15% for Gimme... M (non-stacking)

      // Apply Aiku Defense: 25% reduction per item, max 50% (2 items)
      const aikuReduction = Math.min(aikuDefenseCount, 2) * 0.25;
      robChance = Math.max(0, robChance - aikuReduction); // Ensure robChance doesn't go below 0

      const stealAmount = Math.floor(targetBalance * 0.25); // 25% of target's balance
      const lossAmount = Math.floor(userBalance * 0.50); // 50% of user's balance

      const embed = new EmbedBuilder()
        .setColor('#FFD700')
        .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
        .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() });

      if (robChance <= 0) {
        // Automatic failure due to Aiku Defense
        embed
          .setTitle(`${emoji} Rob Blocked!`)
          .setDescription(`**${target.username}**'s **Aiku Defense** completely shut down your rob attempt!`)
          .addFields(
            { name: 'Your Balance', value: `${userBalance.toLocaleString()} Thunder Coins`, inline: true },
            { name: `${target.username}'s Balance`, value: `${targetBalance.toLocaleString()} Thunder Coins`, inline: true }
          );
      } else if (Math.random() < robChance) {
        balanceData[interaction.user.id] = userBalance + stealAmount;
        balanceData[target.id] = targetBalance - stealAmount;
        embed
          .setTitle(`${emoji} Rob Success!`)
          .setDescription(`You stole **${stealAmount.toLocaleString()} Thunder Coins** from ${target.username}!`)
          .addFields(
            { name: 'Your New Balance', value: `${balanceData[interaction.user.id].toLocaleString()} Thunder Coins`, inline: true },
            { name: `${target.username}'s New Balance`, value: `${balanceData[target.id].toLocaleString()} Thunder Coins`, inline: true }
          );
      } else {
        balanceData[interaction.user.id] = userBalance - lossAmount;
        embed
          .setTitle(`${emoji} Rob Failed!`)
          .setDescription(`You got caught and lost **${lossAmount.toLocaleString()} Thunder Coins**!`)
          .addFields(
            { name: 'Your New Balance', value: `${balanceData[interaction.user.id].toLocaleString()} Thunder Coins`, inline: true }
          );
      }

      if (interaction.user.id !== exemptUserId) {
        cdData[interaction.user.id] = now;
        fs.writeFileSync(cdPath, JSON.stringify(cdData, null, 2));
      }

      fs.writeFileSync(balancePath, JSON.stringify(balanceData, null, 2));

      await interaction.reply({ embeds: [embed] });
    } catch (error) {
      console.error('Rob slash command error:', error);
      await interaction.reply({ content: 'An error occurred!', ephemeral: true });
    }
  },
};