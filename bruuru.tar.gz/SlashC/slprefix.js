const { SlashCommandBuilder, PermissionsBitField, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const emoji = '<:0_Deco_stargold:1363095379364679881>';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setprefix')
    .setDescription('Change the bot prefix for this server (Admin only)')
    .addStringOption(option =>
      option.setName('prefix')
        .setDescription('The new prefix for the server')
        .setRequired(true)
    ),
  async execute(interaction) {
    try {
      // Check for administrator permissions
      if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
        return interaction.reply({
          content: 'You need **Administrator** permissions to use this command!',
          ephemeral: true,
        });
      }

      const newPrefix = interaction.options.getString('prefix').trim();
      if (newPrefix.length > 5) {
        return interaction.reply({
          content: 'The prefix must be 5 characters or less!',
          ephemeral: true,
        });
      }

      // Load or initialize Server.json
      let serverData = {};
      if (fs.existsSync('./Server.json')) {
        serverData = JSON.parse(fs.readFileSync('./Server.json', 'utf8'));
      }

      // Update the prefix for the guild
      serverData[interaction.guild.id] = newPrefix;
      fs.writeFileSync('./Server.json', JSON.stringify(serverData, null, 2));

      // Create success embed
      const embed = new EmbedBuilder()
        .setColor('#FFD700')
        .setTitle(`${emoji} Prefix Updated`)
        .setDescription(`The bot prefix for **${interaction.guild.name}** has been changed to \`${newPrefix}\`!`)
        .setThumbnail(interaction.guild.iconURL())
        .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() })
        .setTimestamp();

      await interaction.reply({ embeds: [embed] });
    } catch (error) {
      console.error('Setprefix slash command error:', error);
      await interaction.reply({
        content: 'An error occurred while setting the prefix!',
        ephemeral: true,
      });
    }
  },
};