const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const invPath = './inventory.json';
const emoji = '<:0_Deco_stargold:1363095379364679881>';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('inventory')
    .setDescription('View your or another user\'s inventory')
    .addUserOption(option =>
      option.setName('user').setDescription('User to check').setRequired(false)
    ),

  async execute(interaction) {
    try {
      const user = interaction.options.getUser('user') || interaction.user;
      let invData = fs.existsSync(invPath) ? JSON.parse(fs.readFileSync(invPath, 'utf8')) : {};

      const userInv = invData[user.id] || {};
      let items = 'No items in inventory!';
      if (Object.keys(userInv).length > 0) {
        items = Object.entries(userInv)
          .map(([item, quantity]) => `**${item}** - ${quantity}`)
          .join('\n');
      }

      const embed = new EmbedBuilder()
        .setColor('#FFD700') // Gold color for consistency
        .setTitle(`${emoji} ${user.username}'s Inventory`)
        .setDescription(
          `**Inventory Contents**\n${items}\n\n` +
          `━━━━━━━━━━━━━━━━━━━━━\n` +
          `*Use \`/shop\` to acquire more items!*`
        )
        .setThumbnail(user.displayAvatarURL({ dynamic: true, size: 128 }))
        .setFooter({
          text: `${interaction.guild.name} | Inventory System`,
          iconURL: interaction.guild.iconURL({ dynamic: true }),
        })
        .setTimestamp();

      await interaction.reply({ embeds: [embed] });
    } catch (error) {
      console.error('Inventory slash command error:', error);
      await interaction.reply({
        content: 'An error occurred while fetching the inventory!',
        ephemeral: true,
      });
    }
  },
};