const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require('discord.js');
const Staffs = require('../Staffs.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('demote')
    .setDescription('Demote a user to a lower role.')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('The user to demote')
        .setRequired(true))
    .addRoleOption(option =>
      option.setName('role')
        .setDescription('The role to demote from (optional)'))
    .addStringOption(option =>
      option.setName('reason')
        .setDescription('Reason for demotion (optional)')),
  async execute(interaction) {
    if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageRoles)) {
      return interaction.reply({
        embeds: [new EmbedBuilder()
          .setColor('#FF0000')
          .setDescription('❌ You do not have permission to manage roles!')],
        ephemeral: true
      });
    }

    if (!interaction.guild.members.me.permissions.has(PermissionsBitField.Flags.ManageRoles)) {
      return interaction.reply({
        embeds: [new EmbedBuilder()
          .setColor('#FF0000')
          .setDescription('❌ I do not have permission to manage roles!')],
        ephemeral: true
      });
    }

    const user = interaction.options.getMember('user');
    const specifiedRole = interaction.options.getRole('role');
    const reason = interaction.options.getString('reason') || 'No reason provided';

    if (!user) {
      return interaction.reply({
        embeds: [new EmbedBuilder()
          .setColor('#FF0000')
          .setDescription('❌ Invalid user provided!')],
        ephemeral: true
      });
    }

    if (user.id === interaction.user.id) {
      return interaction.reply({
        embeds: [new EmbedBuilder()
          .setColor('#FF0000')
          .setDescription('❌ You cannot demote yourself!')],
        ephemeral: true
      });
    }

    const highestRole = interaction.member.roles.highest;
    const botHighestRole = interaction.guild.members.me.roles.highest;

    if (user.roles.highest.position >= highestRole.position) {
      return interaction.reply({
        embeds: [new EmbedBuilder()
          .setColor('#FF0000')
          .setDescription('❌ You cannot demote someone with a role equal to or higher than yours!')],
        ephemeral: true
      });
    }

    let roleToRemove;
    let newRole;

    if (specifiedRole) {
      if (!user.roles.cache.has(specifiedRole.id)) {
        return interaction.reply({
          embeds: [new EmbedBuilder()
            .setColor('#FF0000')
            .setDescription('❌ The user does not have the specified role!')],
          ephemeral: true
        });
      }

      if (specifiedRole.position >= botHighestRole.position) {
        return interaction.reply({
          embeds: [new EmbedBuilder()
            .setColor('#FF0000')
            .setDescription('❌ I cannot remove the specified role as it is higher than my highest role!')],
          ephemeral: true
        });
      }

      roleToRemove = specifiedRole;
    } else {
      // Remove highest role and assign the next lower one
      const sortedRoles = user.roles.cache
        .filter(r => r.id !== interaction.guild.id && r.position < highestRole.position)
        .sort((a, b) => b.position - a.position);

      roleToRemove = sortedRoles.first();
      newRole = sortedRoles.filter(r => r.id !== roleToRemove.id).first();

      if (!roleToRemove || !newRole) {
        return interaction.reply({
          embeds: [new EmbedBuilder()
            .setColor('#FF0000')
            .setDescription('❌ No valid roles found to demote this user!')],
          ephemeral: true
        });
      }
    }

    try {
      await user.roles.remove(roleToRemove);

      if (!specifiedRole && newRole) {
        await user.roles.add(newRole);
      }

      const embed = new EmbedBuilder()
        .setColor('#FF0000')
        .setTitle('User Demoted')
        .setThumbnail(user.user.displayAvatarURL({ dynamic: true }))
        .addFields(
          { name: 'User', value: `${user} (${user.user.tag})`, inline: true },
          { name: 'Demoted By', value: `${interaction.member} (${interaction.user.tag})`, inline: true },
          { name: 'Demoted From', value: `${roleToRemove}`, inline: true },
          { name: 'New Role', value: `${newRole ?? 'None'}`, inline: true },
          { name: 'Reason', value: reason }
        )
        .setFooter({ text: `ID: ${user.id}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
        .setTimestamp();

      await interaction.reply({
        content: `${user}`,
        embeds: [embed]
      });

      const staffLogChannelId = Staffs.getStaffLogChannel(interaction.guild.id);
      if (staffLogChannelId) {
        const staffLogChannel = interaction.guild.channels.cache.get(staffLogChannelId);
        if (staffLogChannel) {
          await staffLogChannel.send({
            content: `${user}`,
            embeds: [embed]
          });
        }
      }
    } catch (error) {
      console.error('Error demoting user:', error);
      await interaction.reply({
        embeds: [new EmbedBuilder()
          .setColor('#FF0000')
          .setDescription('❌ An error occurred while demoting the user!')],
        ephemeral: true
      });
    }
  },
};