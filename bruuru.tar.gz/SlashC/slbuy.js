const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const shopItems = require('../shopItems.js'); // Import shared shop items
const path = './Balance.json';
const invPath = './inventory.json';
const emoji = '<:0_Deco_stargold:1363095379364679881>';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('buy')
    .setDescription('Buy an item from the shop')
    .addStringOption(option =>
      option.setName('item').setDescription('Item to buy').setRequired(true)
    )
    .addIntegerOption(option =>
      option
        .setName('quantity')
        .setDescription('Number of items to buy (default: 1)')
        .setRequired(false)
        .setMinValue(1)
    ),

  async execute(interaction) {
    try {
      const itemName = interaction.options.getString('item');
      const quantity = interaction.options.getInteger('quantity') ?? 1;
      const item = shopItems.find(i => i.name.toLowerCase() === itemName.toLowerCase());

      if (!item) {
        return interaction.reply({ content: 'Invalid item name!', ephemeral: true });
      }

      const totalCost = item.price * quantity;
      let balanceData = fs.existsSync(path) ? JSON.parse(fs.readFileSync(path, 'utf8')) : {};
      let invData = fs.existsSync(invPath) ? JSON.parse(fs.readFileSync(invPath, 'utf8')) : {};

      const userBalance = balanceData[interaction.user.id] ?? 0;
      if (userBalance < totalCost) {
        return interaction.reply({
          content: `Insufficient Thunder Coins! You need **${totalCost.toLocaleString()}** coins for **${quantity} ${item.name}(s)**.`,
          ephemeral: true,
        });
      }

      balanceData[interaction.user.id] = userBalance - totalCost;
      invData[interaction.user.id] = invData[interaction.user.id] || {};
      invData[interaction.user.id][item.name] = (invData[interaction.user.id][item.name] || 0) + quantity;

      fs.writeFileSync(path, JSON.stringify(balanceData, null, 2));
      fs.writeFileSync(invPath, JSON.stringify(invData, null, 2));

      const embed = new EmbedBuilder()
        .setColor('#FFD700')
        .setTitle(`${emoji} Purchase Successful`)
        .setDescription(`Successfully purchased **${quantity} ${item.name}(s)**!`)
        .addFields(
          { name: 'Item', value: item.name, inline: true },
          { name: 'Quantity', value: quantity.toString(), inline: true },
          { name: 'Unit Price', value: `${item.price.toLocaleString()} Thunder Coins`, inline: true },
          { name: 'Total Cost', value: `${totalCost.toLocaleString()} Thunder Coins`, inline: true },
          { name: 'New Balance', value: `${balanceData[interaction.user.id].toLocaleString()} Thunder Coins`, inline: true }
        )
        .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
        .setFooter({ text: `Shop • ${interaction.guild.name}`, iconURL: interaction.guild.iconURL() })
        .setTimestamp();

      await interaction.reply({ embeds: [embed] });
    } catch (error) {
      console.error('Buy command error:', error);
      await interaction.reply({ content: 'An error occurred!', ephemeral: true });
    }
  },
};