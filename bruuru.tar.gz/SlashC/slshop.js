const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const shopItems = require('../shopItems.js'); // Import shared shop items
const emoji = '<:0_Deco_stargold:1363095379364679881>';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('shop')
    .setDescription('View the Thunder Coin shop'),

  async execute(interaction) {
    try {
      const embed = new EmbedBuilder()
        .setColor('#FFD700')
        .setTitle(`${emoji} Thunder Coin Shop`)
        .setDescription('Browse the available items below!')
        .setThumbnail(interaction.guild.iconURL())
        .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() });

      const fields = shopItems.map(item => ({
        name: item.name,
        value: `Price: **${item.price.toLocaleString()} Thunder Coins**\n${item.description || 'No description available.'}`,
        inline: true,
      }));

      embed.addFields(fields);
      await interaction.reply({ embeds: [embed] });
    } catch (error) {
      console.error('Shop command error:', error);
      await interaction.reply({ content: 'An error occurred!', ephemeral: true });
    }
  },
};