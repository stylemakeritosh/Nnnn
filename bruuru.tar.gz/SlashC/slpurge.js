const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('purge')
    .setDescription('Delete a specified number of messages in the channel (up to 1000).')
    .addIntegerOption(opt =>
      opt.setName('amount')
        .setDescription('Number of messages to delete')
        .setRequired(true)
        .setMinValue(1)
        .setMaxValue(1000)
    ),

  async execute(interaction) {
    try {
      const amount = interaction.options.getInteger('amount');

      // Check permissions
      if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
        return interaction.reply({
          content: '❌ You need **Manage Messages** permission to use this command.',
          ephemeral: true
        });
      }

      // Bulk delete messages
      await interaction.channel.bulkDelete(amount, true);

      // Send confirmation embed
      const embed = new EmbedBuilder()
        .setColor('#00FF00')
        .setTitle('🧹 Messages Purged')
        .setDescription(`Successfully deleted **${amount}** message${amount === 1 ? '' : 's'}!`)
        .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() })
        .setTimestamp();

      await interaction.reply({ embeds: [embed] });

      // Delete the embed after 5 seconds
      setTimeout(() => interaction.deleteReply().catch(console.error), 5000);
    } catch (error) {
      console.error('Purge slash command error:', error);
      await interaction.reply({
        content: '❌ An error occurred while purging messages!',
        ephemeral: true
      });
    }
  },
};