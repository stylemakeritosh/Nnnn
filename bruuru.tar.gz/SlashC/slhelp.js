const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const emoji = '<:0_Deco_stargold:1363095379364679881>';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('View all available commands'),

  async execute(interaction) {
    try {
      const categories = {
        Economy: [
          { name: 'balance', description: 'Shows your Thunder Coin balance' },
          { name: 'bank', description: 'Shows bank balance' },
          { name: 'bank t', description: 'Transfer balance into your bank' },
          { name: 'bank w', description: 'Withdraw balance from your bank' },
          { name: 'buy', description: 'Buy item from the shop' },
          { name: 'drop', description: 'Drop balance for others to pick' },
          { name: 'give', description: 'Give Thunder Coins to someone' },
          { name: 'gitem', description: 'Gift an item to someone' },
          { name: 'inventory', description: 'Shows your item inventory' },
          { name: 'rob', description: 'Rob 25% of someone\'s balance (chance of failing)' },
          { name: 'sell', description: 'Sell item from your inventory' },
          { name: 'shop', description: 'Shows shop items' },
        ],
        Fun: [
          { name: 'coinflip', description: 'Bet on heads or tails for 2x your bet' },
          { name: 'daily', description: 'Gives free Thunder Coins when balance is 0' },
          { name: 'fbtest', description: 'Femboy Test! How much of a femboy are you?' },
          { name: 'gcolor', description: 'Guess the color for a bet' },
          { name: 'gnumber', description: 'Guess a number (1-3) for a bet' },
          { name: 'highlow', description: '30% chance to win 3x your balance' },
          { name: 'rps', description: 'Rock Paper Scissors! Win 2.2x your bet' },
          { name: 'ship', description: 'Ship yourself or two people' },
        ],
        Moderation: [
          { name: 'demote', description: 'Remove a role from someone (staff only)' },
          { name: 'lock', description: 'Lock the channel' },
          { name: 'promote', description: 'Add a role to someone (staff only)' },
          { name: 'purge', description: 'Purge messages in the channel' },
          { name: 'rto', description: 'Remove timeout from someone' },
          { name: 'rwarn', description: 'Remove warning from someone' },
          { name: 'to', description: 'Timeout someone' },
          { name: 'unlock', description: 'Unlock the channel' },
          { name: 'warn', description: 'Warn someone' },
          { name: 'warns', description: 'Show current warnings' },
        ],
        Utility: [
          { name: 'banklb', description: 'Shows top 10 bank leaderboard' },
          { name: 'lb', description: 'Shows balance leaderboard' },
          { name: 'setlbprize', description: 'Set leaderboard prize for your server' },
          { name: 'setprefix', description: 'Set bot prefix for the server' },
          { name: 'staff-logs', description: 'View promote and demote logs' },
        ],
      };

      const allCommands = Object.entries(categories).flatMap(([category, cmds]) =>
        cmds.map(cmd => ({ ...cmd, category }))
      );
      const commandsPerPage = 5;
      let currentPage = 0;

      // Generate unique ID based on timestamp, user ID, and interaction ID
      const uniqueId = `${Date.now()}-${interaction.user.id}-${interaction.id}`;

      const generateEmbed = (page) => {
        const start = page * commandsPerPage;
        const end = start + commandsPerPage;
        const pageCommands = allCommands.slice(start, end);

        const embed = new EmbedBuilder()
          .setColor('#FFD700')
          .setTitle(`${emoji} YoBot Command Hub`)
          .setDescription(
            'Explore all YoBot commands below! Use **Yo <command>** for prefix commands or **/<command>** for slash commands.'
          )
          .setThumbnail(interaction.guild?.iconURL() || interaction.client.user.displayAvatarURL())
          .setFooter({
            text: `Page ${page + 1} of ${Math.ceil(allCommands.length / commandsPerPage)} | YoBot - Your Thunder Coin Hub`,
            iconURL: interaction.client.user.displayAvatarURL(),
          })
          .setTimestamp();

        pageCommands.forEach((cmd) => {
          embed.addFields({
            name: `${cmd.category}: \`${cmd.name}\``,
            value: cmd.description,
            inline: false,
          });
        });

        return embed;
      };

      const generateButtons = (page) => {
        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId(`help_back_${uniqueId}`)
            .setLabel('Back')
            .setStyle(ButtonStyle.Secondary)
            .setDisabled(page === 0),
          new ButtonBuilder()
            .setCustomId(`help_next_${uniqueId}`)
            .setLabel('Next')
            .setStyle(ButtonStyle.Primary)
            .setDisabled(page === Math.ceil(allCommands.length / commandsPerPage) - 1)
        );
        return row;
      };

      await interaction.reply({
        embeds: [generateEmbed(currentPage)],
        components: [generateButtons(currentPage)],
      });

      const collector = interaction.channel.createMessageComponentCollector({
        filter: (i) => i.user.id === interaction.user.id && i.customId.includes(uniqueId),
        time: 60000,
      });

      collector.on('collect', async (i) => {
        if (i.customId === `help_next_${uniqueId}`) {
          currentPage++;
        } else if (i.customId === `help_back_${uniqueId}`) {
          currentPage--;
        }

        await i.update({
          embeds: [generateEmbed(currentPage)],
          components: [generateButtons(currentPage)],
        });
      });

      collector.on('end', async () => {
        await interaction.editReply({ components: [] });
      });
    } catch (error) {
      console.error('Help slash command error:', error);
      await interaction.reply({ content: 'An error occurred!', ephemeral: true });
    }
  },
};