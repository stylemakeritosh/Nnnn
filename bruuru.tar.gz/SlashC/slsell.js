const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const shopItems = require('../shopItems.js');
const path = './Balance.json';
const invPath = './inventory.json';
const emoji = '<:0_Deco_stargold:1363095379364679881>';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('sell')
    .setDescription('Sell items from your inventory')
    .addStringOption(option =>
      option.setName('item').setDescription('Item to sell').setRequired(true)
    )
    .addIntegerOption(option =>
      option.setName('amount').setDescription('Amount to sell').setRequired(true).setMinValue(1)
    ),

  async execute(interaction) {
    try {
      const itemName = interaction.options.getString('item');
      const amount = interaction.options.getInteger('amount');
      const item = shopItems.find(i => i.name.toLowerCase() === itemName.toLowerCase());

      if (!item) {
        return interaction.reply({ content: 'Invalid item name!', ephemeral: true });
      }

      let balanceData = fs.existsSync(path) ? JSON.parse(fs.readFileSync(path, 'utf8')) : {};
      let invData = fs.existsSync(invPath) ? JSON.parse(fs.readFileSync(invPath, 'utf8')) : {};

      const userInv = invData[interaction.user.id] || {};
      if (!userInv[item.name] || userInv[item.name] < amount) {
        return interaction.reply({ content: `You don't have ${amount} ${item.name} in your inventory!`, ephemeral: true });
      }

      userInv[item.name] -= amount;
      if (userInv[item.name] === 0) {
        delete userInv[item.name];
      }
      if (Object.keys(userInv).length === 0) {
        delete invData[interaction.user.id];
      } else {
        invData[interaction.user.id] = userInv;
      }
      const totalPrice = item.price * amount;
      balanceData[interaction.user.id] = (balanceData[interaction.user.id] ?? 0) + totalPrice;

      fs.writeFileSync(path, JSON.stringify(balanceData, null, 2));
      fs.writeFileSync(invPath, JSON.stringify(invData, null, 2));

      const embed = new EmbedBuilder()
        .setColor('#FFD700')
        .setTitle(`${emoji} Sale Successful`)
        .setDescription(`You sold **${amount} ${item.name}** for **${totalPrice.toLocaleString()} Thunder Coins**!`)
        .addFields(
          { name: 'New Balance', value: `${balanceData[interaction.user.id].toLocaleString()} Thunder Coins`, inline: true }
        )
        .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
        .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() });

      await interaction.reply({ embeds: [embed] });
    } catch (error) {
      console.error('Sell command error:', error);
      await interaction.reply({ content: 'An error occurred!', ephemeral: true });
    }
  },
};