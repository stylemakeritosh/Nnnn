const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require('discord.js');
const Staffs = require('../Staffs.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('staff-log')
    .setDescription('Set the staff log channel.')
    .addChannelOption(option =>
      option.setName('channel')
        .setDescription('The channel to set as the staff log')
        .setRequired(true)),
  async execute(interaction) {
    if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
      return interaction.reply({
        embeds: [new EmbedBuilder()
          .setColor('#FF0000')
          .setDescription('❌ You do not have permission to manage channels!')],
        ephemeral: true
      });
    }

    const channel = interaction.options.getChannel('channel');
    if (!channel.isTextBased()) {
      return interaction.reply({
        embeds: [new EmbedBuilder()
          .setColor('#FF0000')
          .setDescription('❌ Please select a text-based channel!')],
        ephemeral: true
      });
    }

    try {
      Staffs.setStaffLogChannel(interaction.guild.id, channel.id);

      const embed = new EmbedBuilder()
        .setColor('#00FF00')
        .setTitle('Staff Log Channel Set')
        .addFields(
          { name: 'Channel', value: `${channel}`, inline: true },
          { name: 'Set By', value: `${interaction.member} (${interaction.user.tag})`, inline: true }
        )
        .setTimestamp();

      await interaction.reply({ embeds: [embed] });
    } catch (error) {
      console.error('Error setting staff log channel:', error);
      await interaction.reply({
        embeds: [new EmbedBuilder()
          .setColor('#FF0000')
          .setDescription('❌ An error occurred while setting the staff log channel!')],
        ephemeral: true
      });
    }
  },
};