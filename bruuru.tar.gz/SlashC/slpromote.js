const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require('discord.js');
const Staffs = require('../Staffs.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('promote')
    .setDescription('Promotes a user by adding a role or moving to the next higher role.')
    .addUserOption(option =>
      option
        .setName('user')
        .setDescription('The user to promote')
        .setRequired(true)
    )
    .addRoleOption(option =>
      option
        .setName('role')
        .setDescription('The specific role to promote to (optional)')
        .setRequired(false)
    )
    .setDefaultMemberPermissions(PermissionsBitField.Flags.ManageRoles)
    .setDMPermission(false),

  async execute(interaction) {
    await interaction.deferReply();

    const user = interaction.options.getMember('user');
    const inputRole = interaction.options.getRole('role');

    if (!interaction.guild.members.me.permissions.has(PermissionsBitField.Flags.ManageRoles)) {
      return interaction.editReply({
        embeds: [new EmbedBuilder()
          .setColor('#00FF00')
          .setDescription('❌ I do not have permission to manage roles!')]
      });
    }

    if (!user) {
      return interaction.editReply({
        embeds: [new EmbedBuilder()
          .setColor('#00FF00')
          .setDescription('❌ Invalid user provided!')]
      });
    }

    if (user.id === interaction.user.id) {
      return interaction.editReply({
        embeds: [new EmbedBuilder()
          .setColor('#00FF00')
          .setDescription('❌ You cannot promote yourself!')]
      });
    }

    const highestRole = interaction.member.roles.highest;
    const botHighestRole = interaction.guild.members.me.roles.highest;

    if (user.roles.highest.position >= highestRole.position) {
      return interaction.editReply({
        embeds: [new EmbedBuilder()
          .setColor('#00FF00')
          .setDescription('❌ You cannot promote someone with a role equal to or higher than yours!')]
      });
    }

    let roleToAdd;

    if (inputRole) {
      roleToAdd = inputRole;

      if (user.roles.cache.has(roleToAdd.id)) {
        return interaction.editReply({
          embeds: [new EmbedBuilder()
            .setColor('#00FF00')
            .setDescription(`❌ ${user} already has the role ${roleToAdd}`)]
        });
      }
    } else {
      const userHighestRole = user.roles.highest;
      const validRoles = interaction.guild.roles.cache
        .filter(r => r.position > userHighestRole.position && r.position < highestRole.position && r.position < botHighestRole.position)
        .sort((a, b) => a.position - b.position);

      roleToAdd = validRoles.first();
      if (!roleToAdd) {
        return interaction.editReply({
          embeds: [new EmbedBuilder()
            .setColor('#00FF00')
            .setDescription(`❌ No valid role found to promote ${user}`)]
        });
      }
    }

    if (roleToAdd.position >= botHighestRole.position) {
      return interaction.editReply({
        embeds: [new EmbedBuilder()
          .setColor('#00FF00')
          .setDescription(`❌ I cannot add ${roleToAdd} because it is higher than my highest role!`)]
        });
      }

    try {
      // If no specific role was provided, remove the highest role before adding the new one
      if (!inputRole) {
        const userHighestRole = user.roles.highest;
        if (userHighestRole.position < highestRole.position && userHighestRole.position < botHighestRole.position) {
          await user.roles.remove(userHighestRole);
        }
      }

      await user.roles.add(roleToAdd);

      const embed = new EmbedBuilder()
        .setColor('#00FF00')
        .setTitle('User Promoted')
        .setThumbnail(user.user.displayAvatarURL({ dynamic: true }))
        .addFields(
          { name: 'User', value: `${user} (${user.user.tag})`, inline: true },
          { name: 'Promoted By', value: `${interaction.member} (${interaction.user.tag})`, inline: true },
          { name: 'Promoted Role', value: `${roleToAdd}`, inline: true }
        )
        .setFooter({ text: `ID: ${user.id}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
        .setTimestamp();

      await interaction.editReply({
        content: `${user}`,
        embeds: [embed]
      });

      const staffLogChannelId = Staffs.getStaffLogChannel(interaction.guild.id);
      if (staffLogChannelId) {
        const staffLogChannel = interaction.guild.channels.cache.get(staffLogChannelId);
        if (staffLogChannel) {
          await staffLogChannel.send({
            content: `${user}`,
            embeds: [embed]
          });
        }
      }

    } catch (error) {
      console.error('Error promoting user:', error);
      await interaction.editReply({
        embeds: [new EmbedBuilder()
          .setColor('#00FF00')
          .setDescription('❌ An error occurred while promoting the user!')]
      });
    }
  },
};