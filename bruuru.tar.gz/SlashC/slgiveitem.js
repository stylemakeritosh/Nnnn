const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const shopItems = require('../shopItems.js'); // Import shared shop items
const invPath = './inventory.json';
const emoji = '<:0_Deco_stargold:1363095379364679881>';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('gitem')
    .setDescription('Give an item to another user')
    .addUserOption(option => option.setName('user').setDescription('User to give item to').setRequired(true))
    .addStringOption(option => option.setName('item').setDescription('Item name').setRequired(true))
    .addIntegerOption(option =>
      option
        .setName('quantity')
        .setDescription('Number of items to give (default: 1)')
        .setRequired(false)
        .setMinValue(1)
    ),

  async execute(interaction) {
    try {
      const targetUser = interaction.options.getUser('user');
      const itemName = interaction.options.getString('item').trim();
      const quantity = interaction.options.getInteger('quantity') ?? 1;

      // Validate item name (case-insensitive)
      const validItem = shopItems.find(i => i.name.toLowerCase() === itemName.toLowerCase());
      if (!validItem) {
        return interaction.reply({
          content: `Invalid item! Choose from: ${shopItems.map(i => i.name).join(', ')}`,
          ephemeral: true,
        });
      }

      const invData = fs.existsSync(invPath) ? JSON.parse(fs.readFileSync(invPath, 'utf8')) : {};
      const userInv = invData[interaction.user.id] || {};

      if (!userInv[validItem.name] || userInv[validItem.name] < quantity) {
        return interaction.reply({
          content: `You don’t have enough **${validItem.name}** in your inventory! You have **${userInv[validItem.name] || 0}**.`,
          ephemeral: true,
        });
      }

      // Update giver's inventory
      userInv[validItem.name] -= quantity;
      if (userInv[validItem.name] === 0) delete userInv[validItem.name];
      invData[interaction.user.id] = userInv;

      // Update receiver's inventory
      invData[targetUser.id] = invData[targetUser.id] || {};
      invData[targetUser.id][validItem.name] = (invData[targetUser.id][validItem.name] || 0) + quantity;

      fs.writeFileSync(invPath, JSON.stringify(invData, null, 2));

      const embed = new EmbedBuilder()
        .setColor('#00CED1')
        .setTitle(`${emoji} Item Gifted!`)
        .setDescription(`${interaction.user} gave **${quantity} ${validItem.name}(s)** to ${targetUser}!`)
        .addFields(
          { name: 'Item', value: validItem.name, inline: true },
          { name: 'Quantity', value: quantity.toString(), inline: true },
          {
            name: 'Giver’s Inventory',
            value: `${userInv[validItem.name] || 0} ${validItem.name}(s) remaining`,
            inline: true,
          }
        )
        .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
        .setFooter({ text: `Shop • ${interaction.guild.name}`, iconURL: interaction.guild.iconURL() })
        .setTimestamp();

      await interaction.reply({ embeds: [embed] });
    } catch (error) {
      console.error('Gitem slash command error:', error);
      await interaction.reply({ content: 'An error occurred!', ephemeral: true });
    }
  },
};