const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require('discord.js');
const emoji = '<:0_Deco_stargold:1363095379364679881>';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('lock')
    .setDescription('Lock a channel to prevent messages.')
    .addChannelOption(option => option.setName('channel').setDescription('Channel to lock (optional)')),
  async execute(interaction) {
    try {
      await interaction.deferReply();

      // Check permissions
      if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
        return interaction.editReply('❌ You need **Manage Channels** permission to use this command!');
      }

      // Get channel
      const channel = interaction.options.getChannel('channel') || interaction.channel;
      if (!channel || !channel.isTextBased()) {
        return interaction.editReply('Please select a valid text channel!');
      }

      // Lock channel
      await channel.permissionOverwrites.edit(interaction.guild.roles.everyone, {
        SendMessages: false,
      });

      // Create embed
      const embed = new EmbedBuilder()
        .setColor('#FFD700')
        .setTitle(`${emoji} Channel Locked`)
        .setDescription(`🔒 **${channel.name}** has been locked!`)
        .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() })
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      console.error('Lock slash command error:', error);
      await interaction.editReply('⚠️ An error occurred while locking the channel!');
    }
  },
};