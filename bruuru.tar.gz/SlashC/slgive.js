const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = './Balance.json';
const emoji = '<:0_Deco_stargold:1363095379364679881>';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('give')
    .setDescription('Give Thunder Coins to another user')
    .addUserOption(option =>
      option.setName('user').setDescription('User to give coins to').setRequired(true)
    )
    .addIntegerOption(option =>
      option.setName('amount').setDescription('Amount to give').setRequired(true).setMinValue(1)
    ),

  async execute(interaction) {
    try {
      const targetUser = interaction.options.getUser('user');
      const amount = interaction.options.getInteger('amount');

      if (targetUser.bot) {
        return interaction.reply({ content: 'You cannot give Thunder Coins to a bot!', ephemeral: true });
      }

      if (targetUser.id === interaction.user.id) {
        return interaction.reply({ content: 'You cannot give Thunder Coins to yourself!', ephemeral: true });
      }

      let balanceData = fs.existsSync(path) ? JSON.parse(fs.readFileSync(path, 'utf8')) : {};
      const userBalance = balanceData[interaction.user.id] ?? 0;

      if (amount > userBalance) {
        return interaction.reply({ content: 'Insufficient Thunder Coins!', ephemeral: true });
      }

      balanceData[interaction.user.id] = userBalance - amount;
      balanceData[targetUser.id] = (balanceData[targetUser.id] ?? 0) + amount;

      fs.writeFileSync(path, JSON.stringify(balanceData, null, 2));

      const embed = new EmbedBuilder()
        .setColor('#FFD700')
        .setTitle(`${emoji} Thunder Coins Gifted`)
        .setDescription(`You gave **${amount.toLocaleString()} Thunder Coins** to **${targetUser.username}**!`)
        .addFields(
          { name: 'Your New Balance', value: `${balanceData[interaction.user.id].toLocaleString()} Thunder Coins`, inline: true },
          { name: `${targetUser.username}'s New Balance`, value: `${balanceData[targetUser.id].toLocaleString()} Thunder Coins`, inline: true }
        )
        .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
        .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() });

      await interaction.reply({ embeds: [embed] });
    } catch (error) {
      console.error('Give command error:', error);
      await interaction.reply({ content: 'An error occurred!', ephemeral: true });
    }
  },
};