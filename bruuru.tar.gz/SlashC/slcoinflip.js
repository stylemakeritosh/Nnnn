const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = './Balance.json';
const emoji = '<:0_Deco_stargold:1363095379364679881>';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('coinflip')
    .setDescription('Bet Thunder Coins on a coin flip with a 50% chance to double your bet!')
    .addIntegerOption(opt =>
      opt.setName('amount').setDescription('Amount to bet').setRequired(true).setMinValue(1)
    )
    .addStringOption(opt =>
      opt.setName('guess').setDescription('Heads or Tails').setRequired(true).addChoices(
        { name: 'Heads', value: 'heads' },
        { name: 'Tails', value: 'tails' }
      )
    ),

  async execute(interaction) {
    try {
      const userId = interaction.user.id;
      const amount = interaction.options.getInteger('amount');
      const guess = interaction.options.getString('guess');

      let data = fs.existsSync(path) ? JSON.parse(fs.readFileSync(path, 'utf8')) : {};
      const balance = data[userId] ?? 0;

      if (amount > balance) {
        return interaction.reply({
          content: '❌ Insufficient Thunder Coins! Use `/daily` to get more.',
          ephemeral: true
        });
      }

      // Animation sequence
      await interaction.reply('Flipping The Coin <a:coinspin:1363362113950843050>');
      await new Promise(resolve => setTimeout(resolve, 1000));
      await interaction.editReply("Let's see...");
      await new Promise(resolve => setTimeout(resolve, 1000));
      await interaction.editReply('You Got...');
      await new Promise(resolve => setTimeout(resolve, 1000));

      const flip = Math.random() < 0.5 ? 'heads' : 'tails';
      const isWin = guess === flip;
      const reward = isWin ? amount : -amount;
      const newBalance = balance + reward;

      data[userId] = newBalance;
      fs.writeFileSync(path, JSON.stringify(data, null, 2));

      const embed = new EmbedBuilder()
        .setColor(isWin ? '#00FF00' : '#FF0000')
        .setTitle(`${emoji} Coin Flip`)
        .setDescription(isWin ? `🎉 **${flip}**! You doubled your bet!` : `😔 **${flip}**. Better luck next time!`)
        .addFields(
          { name: 'Guess', value: guess.charAt(0).toUpperCase() + guess.slice(1), inline: true },
          { name: 'Bet', value: `${amount.toLocaleString()} TC`, inline: true },
          { name: 'Payout', value: `${reward > 0 ? '+' : ''}${reward.toLocaleString()} TC`, inline: true },
          { name: 'Balance', value: `${newBalance.toLocaleString()} TC`, inline: true }
        )
        .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
        .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() });

      await interaction.editReply({ content: null, embeds: [embed] });
    } catch (error) {
      console.error('Coinflip command error:', error);
      await interaction.reply({ content: 'An error occurred!', ephemeral: true });
    }
  },
};