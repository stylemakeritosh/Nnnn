const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = './prize.json';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setlbprize')
    .setDescription('Set the leaderboard prize role and time interval')
    .addStringOption(option =>
      option.setName('role')
        .setDescription('The name of the role to award to the top leaderboard user')
        .setRequired(true)
    )
    .addIntegerOption(option =>
      option.setName('hours')
        .setDescription('Time interval in hours (default: 24)')
        .setMinValue(1)
        .setRequired(false)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    try {
      await interaction.deferReply();

      const roleName = interaction.options.getString('role');
      const hours = interaction.options.getInteger('hours') || 24;
      const nextAwardTime = Date.now() + hours * 60 * 60 * 1000;

      // Find role by name (case-insensitive, partial match)
      const role = interaction.guild.roles.cache.find(r => 
        r.name.toLowerCase().includes(roleName.toLowerCase())
      ) || interaction.guild.roles.cache.find(r => 
        r.name.toLowerCase() === roleName.toLowerCase()
      );

      if (!role) {
        return interaction.editReply({
          content: `No role found matching "${roleName}". Please check the role name and try again.`,
          ephemeral: true,
        });
      }

      // Check if role is higher than user's highest role
      const userHighestRole = interaction.member.roles.highest;
      if (role.position >= userHighestRole.position) {
        return interaction.editReply({
          content: 'You cannot set a prize role that is equal to or higher than your highest role.',
          ephemeral: true,
        });
      }

      // Validate role
      if (!role.editable) {
        return interaction.editReply({
          content: 'I cannot assign this role. Please ensure my permissions are set correctly and the role is below my highest role.',
          ephemeral: true,
        });
      }

      // Load existing prize data
      let prizeData = {};
      if (fs.existsSync(path)) {
        prizeData = JSON.parse(fs.readFileSync(path));
      }

      // Update or set prize data for this guild
      prizeData[interaction.guild.id] = {
        roleId: role.id,
        guildId: interaction.guild.id,
        intervalHours: hours,
        nextAwardTime,
      };

      // Save updated prize data
      fs.writeFileSync(path, JSON.stringify(prizeData, null, 2));

      // Create embed
      const embed = new EmbedBuilder()
        .setColor('#FFD700')
        .setTitle('🏆 Leaderboard Prize Set')
        .setDescription(`The leaderboard prize has been configured successfully! ${prizeData[interaction.guild.id] ? 'Previous prize replaced.' : ''}`)
        .addFields(
          { name: '🎁 Prize Role', value: `<@&${role.id}>`, inline: true },
          { name: '⏰ Interval', value: `${hours} hours`, inline: true },
          { name: '📅 Next Award', value: `<t:${Math.floor(nextAwardTime / 1000)}:R>`, inline: false }
        )
        .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
        .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() })
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      console.error('Set leaderboard prize error:', error);
      await interaction.editReply({
        content: 'An error occurred while setting the leaderboard prize.',
        ephemeral: true,
      });
    }
  },
};