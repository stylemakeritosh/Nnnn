const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require('discord.js');
const emoji = '<:0_Deco_stargold:1363095379364679881>';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('timeout')
    .setDescription('Timeout a user for 1s to 4w.')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('User to timeout.')
        .setRequired(true)
    )
    .addStringOption(option =>
      option.setName('duration')
        .setDescription('Duration (e.g., 30s, 1m, 1h, 1d, 1w).')
        .setRequired(true)
    )
    .addStringOption(option =>
      option.setName('reason')
        .setDescription('Reason for timeout.')
        .setRequired(false)
    ),
  async execute(interaction) {
    try {
      await interaction.deferReply();

      if (!interaction.guild.members.me.permissions.has(PermissionsBitField.Flags.ModerateMembers)) {
        return interaction.editReply('⚠️ I lack permission to timeout members!');
      }
      if (!interaction.member.permissions.has(PermissionsBitField.Flags.ModerateMembers)) {
        return interaction.editReply('⚠️ You lack permission to timeout members!');
      }

      const target = interaction.options.getMember('user');
      if (!target) return interaction.editReply('Please select a valid user!');
      if (target.id === interaction.user.id) return interaction.editReply('You cannot timeout yourself!');
      if (target.id === interaction.client.user.id) return interaction.editReply('You cannot timeout me!');

      const userHighestRole = interaction.member.roles.highest;
      const targetHighestRole = target.roles.highest;
      if (userHighestRole.position <= targetHighestRole.position) {
        return interaction.editReply('You cannot timeout users with equal or higher roles!');
      }

      if (!target.moderatable) {
        return interaction.editReply('I cannot timeout this user! They may be the server owner or have higher permissions.');
      }

      const durationInput = interaction.options.getString('duration');
      const timeUnits = { s: 1, m: 60, h: 3600, d: 86400, w: 604800 };
      const match = durationInput.match(/^(\d+)([smhdw])$/);
      if (!match) return interaction.editReply('Invalid duration! Use 1s to 4w.');

      const [_, value, unit] = match;
      const seconds = parseInt(value) * timeUnits[unit];
      if (seconds < 1 || seconds > 4 * 604800) {
        return interaction.editReply('Duration must be 1s to 4w!');
      }

      const reason = interaction.options.getString('reason') || 'No reason provided';
      await target.timeout(seconds * 1000, `Timed out by ${interaction.user.tag}: ${reason}`);

      const embed = new EmbedBuilder()
        .setColor('#FF5555')
        .setTitle(`${emoji} Timeout Applied`)
        .addFields(
          { name: 'User', value: `<@${target.id}>`, inline: true },
          { name: 'Duration', value: durationInput, inline: true },
          { name: 'Reason', value: reason, inline: true }
        )
        .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() || 'https://cdn.discordapp.com/embed/avatars/0.png' })
        .setTimestamp();

      await interaction.editReply({ content: `<@${target.id}> has been timed out!`, embeds: [embed] });
    } catch (error) {
      console.error('Timeout slash command error:', error);
      await interaction.editReply('⚠️ Error timing out user!');
    }
  },
};