const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const fs = require('fs');
const warnsPath = './warns.json';
const emoji = '<:0_Deco_stargold:1363095379364679881>';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warns')
    .setDescription('View warnings for a user')
    .addUserOption(option =>
      option.setName('user').setDescription('The user to check (defaults to self)').setRequired(false)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
  async execute(interaction) {
    try {
      // Defer reply
      await interaction.deferReply();

      // Check bot permissions
      if (!interaction.guild.members.me.permissions.has('ModerateMembers')) {
        return interaction.editReply('⚠️ I need the `Moderate Members` permission to view warnings!');
      }

      // Get user (default to interaction user)
      const user = interaction.options.getUser('user') || interaction.user;

      // Read warns data
      const warnsData = fs.existsSync(warnsPath) ? JSON.parse(fs.readFileSync(warnsPath, 'utf8')) : {};
      const guildWarns = warnsData[interaction.guild.id] || {};
      const userWarns = guildWarns[user.id] || [];

      // Create embed
      const embed = new EmbedBuilder()
        .setColor('#FFD700')
        .setTitle(`${emoji} Warnings for ${user.tag}`)
        .setThumbnail(interaction.guild.iconURL({ dynamic: true }) || 'https://cdn.discordapp.com/embed/avatars/0.png')
        .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() })
        .setTimestamp();

      // Build warnings list
      let warningsText = userWarns.length
        ? await Promise.all(
            userWarns.map(async warn => {
              const mod = await interaction.client.users.fetch(warn.moderatorId).catch(() => null);
              return `**Warning ${warn.id}**\nReason: ${warn.reason}\nDate: <t:${Math.floor(warn.date / 1000)}:R>\nModerator: ${mod ? mod.tag : 'Unknown'}`;
            })
          ).then(lines => lines.join('\n\n'))
        : 'No warnings found!';

      embed.addFields({ name: `Total Warnings: ${userWarns.length}`, value: warningsText, inline: false });

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      console.error('Warns slash command error:', error);
      await interaction.editReply('⚠️ An error occurred while fetching warnings!');
    }
  },
};