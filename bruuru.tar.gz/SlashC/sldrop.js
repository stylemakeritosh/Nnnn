const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = './Balance.json';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('drop')
    .setDescription('Drop Thunder Coins for others to pick')
    .addIntegerOption(option => option.setName('amount').setDescription('Amount to drop').setRequired(true))
    .addChannelOption(option => option.setName('channel').setDescription('Channel to drop in').setRequired(false)),

  async execute(interaction) {
    try {
      const amount = interaction.options.getInteger('amount');
      if (amount <= 0) return interaction.reply({ content: 'Please specify a valid amount!', ephemeral: true });

      let channel = interaction.options.getChannel('channel') || interaction.channel;
      if (!channel.isTextBased()) return interaction.reply({ content: 'Invalid channel!', ephemeral: true });

      const data = JSON.parse(fs.readFileSync(path, 'utf8'));
      if (!data[interaction.user.id] || data[interaction.user.id] < amount) {
        return interaction.reply({ content: 'You don’t have enough Thunder Coins!', ephemeral: true });
      }

      const embed = new EmbedBuilder()
        .setColor('#FF4500')
        .setTitle('💰 Thunder Coin Drop!')
        .setDescription(`**${amount} Thunder Coins** dropped by ${interaction.user}!\nType **\`pick\`** to claim them!`)
        .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
        .setFooter({ text: `Thunder Hub | ${interaction.guild.name}`, iconURL: interaction.client.user.displayAvatarURL() })
        .setTimestamp();

      await interaction.reply({ content: 'Drop initiated!', ephemeral: true });
      channel.send({ embeds: [embed] });

      data[interaction.user.id] -= amount;
      fs.writeFileSync(path, JSON.stringify(data, null, 2));

      const filter = msg => msg.content.toLowerCase() === 'pick' && msg.author.id !== interaction.user.id;
      const collector = channel.createMessageCollector({ filter, time: 60000, max: 1 });

      collector.on('collect', msg => {
        data[msg.author.id] = (data[msg.author.id] || 0) + amount;
        fs.writeFileSync(path, JSON.stringify(data, null, 2));

        const successEmbed = new EmbedBuilder()
          .setColor('#00FF00')
          .setTitle('🎉 Coins Claimed!')
          .setDescription(`${msg.author} picked up **${amount} Thunder Coins**!`)
          .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
          .setFooter({ text: `Thunder Hub | ${interaction.guild.name}`, iconURL: interaction.client.user.displayAvatarURL() })
          .setTimestamp();

        channel.send({ embeds: [successEmbed] });
      });

      collector.on('end', collected => {
        if (collected.size === 0) {
          const expiredEmbed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('⏰ Drop Expired!')
            .setDescription(`No one picked up the **${amount} Thunder Coins**. They’re gone!`)
            .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
            .setFooter({ text: `Thunder Hub | ${interaction.guild.name}`, iconURL: interaction.client.user.displayAvatarURL() })
            .setTimestamp();

          channel.send({ embeds: [expiredEmbed] });
        }
      });
    } catch (error) {
      console.error('Drop slash error:', error);
      await interaction.reply({ content: 'An error occurred!', ephemeral: true });
    }
  },
};