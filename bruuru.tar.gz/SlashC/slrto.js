const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require('discord.js');
const emoji = '<:0_Deco_stargold:1363095379364679881>';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('remove-timeout')
    .setDescription('Remove a user’s timeout.')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('User to remove timeout from.')
        .setRequired(true)
    )
    .addStringOption(option =>
      option.setName('reason')
        .setDescription('Reason for removing timeout.')
        .setRequired(false)
    ),
  async execute(interaction) {
    try {
      await interaction.deferReply();

      if (!interaction.guild.members.me.permissions.has(PermissionsBitField.Flags.ModerateMembers)) {
        return interaction.editReply('⚠️ I lack permission to manage timeouts!');
      }
      if (!interaction.member.permissions.has(PermissionsBitField.Flags.ModerateMembers)) {
        return interaction.editReply('⚠️ You lack permission to manage timeouts!');
      }

      const target = interaction.options.getMember('user');
      if (!target) return interaction.editReply('Please select a valid user!');

      const userHighestRole = interaction.member.roles.highest;
      const targetHighestRole = target.roles.highest;
      if (userHighestRole.position <= targetHighestRole.position) {
        return interaction.editReply('You cannot remove timeouts from users with equal or higher roles!');
      }

      if (!target.moderatable) {
        return interaction.editReply('I cannot manage this user’s timeout! They may be the server owner or have higher permissions.');
      }

      if (!target.isCommunicationDisabled()) {
        return interaction.editReply('This user is not timed out!');
      }

      const reason = interaction.options.getString('reason') || 'No reason provided';
      await target.timeout(null, `Timeout removed by ${interaction.user.tag}: ${reason}`);

      const embed = new EmbedBuilder()
        .setColor('#55FF55')
        .setTitle(`${emoji} Timeout Removed`)
        .addFields(
          { name: 'User', value: `<@${target.id}>`, inline: true },
          { name: 'Reason', value: reason, inline: true }
        )
        .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() || 'https://cdn.discordapp.com/embed/avatars/0.png' })
        .setTimestamp();

      await interaction.editReply({ content: `Timeout removed for <@${target.id}>!`, embeds: [embed] });
    } catch (error) {
      console.error('Remove timeout slash command error:', error);
      await interaction.editReply('⚠️ Error removing timeout!');
    }
  },
};