const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const fs = require('fs');
const warnsPath = './warns.json';
const emoji = '<:0_Deco_stargold:1363095379364679881>';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('Warn a user with a reason')
    .addUserOption(option =>
      option.setName('user').setDescription('The user to warn').setRequired(true)
    )
    .addStringOption(option =>
      option.setName('reason').setDescription('Reason for the warning').setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
  async execute(interaction) {
    try {
      // Defer reply
      await interaction.deferReply();

      // Check bot permissions
      if (!interaction.guild.members.me.permissions.has('ModerateMembers')) {
        return interaction.editReply('⚠️ I need the `Moderate Members` permission to warn users!');
      }

      // Get user
      const user = interaction.options.getUser('user');
      if (user.bot) {
        return interaction.editReply('⚠️ You cannot warn bots!');
      }

      // Get reason
      const reason = interaction.options.getString('reason');

      // Read warns data
      let warnsData = {};
      try {
        if (fs.existsSync(warnsPath)) {
          warnsData = JSON.parse(fs.readFileSync(warnsPath, 'utf8'));
        }
      } catch (error) {
        console.error('Error reading warns.json:', error);
        return interaction.editReply('⚠️ Failed to read warnings data!');
      }

      const guildWarns = warnsData[interaction.guild.id] || {};
      const userWarns = guildWarns[user.id] || [];

      // Add new warning
      const warnId = userWarns.length + 1;
      userWarns.push({
        id: warnId,
        reason,
        date: Date.now(),
        moderatorId: interaction.user.id,
      });

      // Update warns data
      guildWarns[user.id] = userWarns;
      warnsData[interaction.guild.id] = guildWarns;
      try {
        fs.writeFileSync(warnsPath, JSON.stringify(warnsData, null, 2));
      } catch (error) {
        console.error('Error writing to warns.json:', error);
        return interaction.editReply('⚠️ Failed to save warnings data!');
      }

      // Create embed
      const embed = new EmbedBuilder()
        .setColor('#FFD700')
        .setTitle(`${emoji} User Warned`)
        .setDescription(`**${user.tag}** has been warned!`)
        .addFields(
          { name: 'Warning', value: `This is your **${warnId}${warnId === 1 ? 'st' : warnId === 2 ? 'nd' : warnId === 3 ? 'rd' : 'th'}** warning!`, inline: true },
          { name: 'Reason', value: reason, inline: true }
        )
        .setThumbnail(interaction.guild.iconURL({ dynamic: true }) || 'https://cdn.discordapp.com/embed/avatars/0.png')
        .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() })
        .setTimestamp();

      // Send reply with user mention outside embed
      await interaction.editReply({ content: `<@${user.id}>`, embeds: [embed] });
    } catch (error) {
      console.error('Warn slash command error:', error);
      await interaction.editReply('⚠️ An error occurred while issuing the warning!');
    }
  },
};