const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const fs = require('fs');
const warnsPath = './warns.json';
const emoji = '<:0_Deco_stargold:1363095379364679881>';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('rwarn')
    .setDescription('Remove a specific warning from a user')
    .addUserOption(option =>
      option.setName('user').setDescription('The user to remove a warning from').setRequired(true)
    )
    .addIntegerOption(option =>
      option.setName('warnid').setDescription('The warning ID to remove').setRequired(true).setMinValue(1)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
  async execute(interaction) {
    try {
      // Defer reply
      await interaction.deferReply();

      // Check bot permissions
      if (!interaction.guild.members.me.permissions.has('ModerateMembers')) {
        return interaction.editReply('⚠️ I need the `Moderate Members` permission to remove warnings!');
      }

      // Get user
      const user = interaction.options.getUser('user');
      if (user.bot) return interaction.editReply('⚠️ You cannot remove warnings from bots!');

      // Get warn ID
      const warnId = interaction.options.getInteger('warnid');

      // Read warns data
      const warnsData = fs.existsSync(warnsPath) ? JSON.parse(fs.readFileSync(warnsPath, 'utf8')) : {};
      const guildWarns = warnsData[interaction.guild.id] || {};
      const userWarns = guildWarns[user.id] || [];

      // Find and remove warning
      const warnIndex = userWarns.findIndex(w => w.id === warnId);
      if (warnIndex === -1) return interaction.editReply(`⚠️ Warning #${warnId} not found for ${user.tag}!`);

      const [removedWarn] = userWarns.splice(warnIndex, 1);

      // Reassign IDs to maintain sequential order
      userWarns.forEach((warn, index) => (warn.id = index + 1));

      // Update warns data
      if (userWarns.length > 0) {
        guildWarns[user.id] = userWarns;
      } else {
        delete guildWarns[user.id];
      }
      warnsData[interaction.guild.id] = guildWarns;
      fs.writeFileSync(warnsPath, JSON.stringify(warnsData, null, 2));

      // Create embed
      const embed = new EmbedBuilder()
        .setColor('#FFD700')
        .setTitle(`${emoji} Warning Removed`)
        .setDescription(`Removed warning #${warnId} from **${user.tag}**!`)
        .addFields(
          { name: 'Reason', value: removedWarn.reason, inline: true },
          { name: 'Remaining Warnings', value: `${userWarns.length}`, inline: true }
        )
        .setThumbnail(interaction.guild.iconURL({ dynamic: true }) || 'https://cdn.discordapp.com/embed/avatars/0.png')
        .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() })
        .setTimestamp();

      // Send reply with user mention outside embed
      await interaction.editReply({ content: `<@${user.id}>`, embeds: [embed] });
    } catch (error) {
      console.error('Rwarn slash command error:', error);
      await interaction.editReply('⚠️ An error occurred while removing the warning!');
    }
  },
};