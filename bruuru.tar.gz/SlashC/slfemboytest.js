const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('fbtest')
    .setDescription('Test how much of a femboy you or someone else is!')
    .addUserOption(option =>
      option.setName('user').setDescription('Who to test').setRequired(false)
    ),
  async execute(interaction) {
    try {
      // Defer reply
      await interaction.deferReply();

      // Get user (option or command user)
      const user = interaction.options.getUser('user') || interaction.user;

      // Generate random percentage (1–101)
      const percent = Math.floor(Math.random() * 101) + 1;

      // Define flirty Gen Z descriptions for every 10% range
      const vibes = {
        10: 'Just a hint of femboy charm, but you’re catching my eye already.',
        20: 'Soft boi vibes sneaking in, wanna borrow my skirt?',
        30: 'You’re teasing femboy energy, and I’m kinda into it.',
        40: 'Halfway to stealing hearts with that femboy glow, keep it up.',
        50: 'Perfect mix of masc and fab, you’re making me blush.',
        60: 'Serving femboy realness, babe, you’ve got my attention.',
        70: 'High-key femboy vibes, and I’m falling for it hard.',
        80: 'Femboy royalty, you’re out here breaking hearts.',
        90: 'Iconic femboy energy, I can’t stop staring, gorgeous.',
        100: 'Ultimate femboy perfection, you’ve got me weak.',
        101: 'Femboy beyond this world, I’m totally enchanted.'
      };

      // Get description based on nearest 10% (or 101)
      const vibeKey = percent === 101 ? 101 : Math.round(percent / 10) * 10;
      const vibe = vibes[vibeKey] || 'Femboy mystery, and I’m dying to know more.';

      // Create embed
      const embed = new EmbedBuilder()
        .setColor('#FF69B4') // Hot pink for flirty aesthetic
        .setTitle('🌸 Femboy Test Results')
        .setDescription(`**${user.username} is ${percent}% femboy!**\n${vibe}`)
        .setThumbnail(user.displayAvatarURL({ dynamic: true, size: 128 }))
        .setFooter({ text: 'Keep slaying, darling.' })
        .setTimestamp();

      // Send embed
      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      console.error('Femboy test slash command error:', error);
      await interaction.editReply({
        content: 'Oh no, something broke, babe. Try again?',
        ephemeral: true,
      });
    }
  },
};