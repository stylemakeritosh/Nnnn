const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = './Balance.json';
const emoji = '<:0_Deco_stargold:1363095379364679881>';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('rps')
    .setDescription('Bet Thunder Coins on Rock, Paper, Scissors with a 2.2x payout on win!')
    .addStringOption(opt =>
      opt.setName('choice')
        .setDescription('Your choice')
        .setRequired(true)
        .addChoices(
          { name: 'Rock', value: 'rock' },
          { name: 'Paper', value: 'paper' },
          { name: 'Scissors', value: 'scissors' }
        )
    )
    .addIntegerOption(opt =>
      opt.setName('amount')
        .setDescription('Amount to bet')
        .setRequired(true)
        .setMinValue(1)
    ),

  async execute(interaction) {
    try {
      const userId = interaction.user.id;
      const choice = interaction.options.getString('choice').toLowerCase();
      const amount = interaction.options.getInteger('amount');

      // Load balance
      let data = fs.existsSync(path) ? JSON.parse(fs.readFileSync(path, 'utf8')) : {};
      const balance = data[userId] ?? 0;

      if (amount > balance) {
        return interaction.reply({
          content: '❌ Insufficient Thunder Coins! Try `/daily` for more.',
          ephemeral: true
        });
      }

      // Animation sequence
      await interaction.reply('Playing Rock, Paper, Scissors... ✊✋✌');
      await new Promise(resolve => setTimeout(resolve, 1000));
      await interaction.editReply('Choosing...');
      await new Promise(resolve => setTimeout(resolve, 1000));
      await interaction.editReply('Result...');
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Bot's choice and outcome
      const choices = ['rock', 'paper', 'scissors'];
      const botChoice = choices[Math.floor(Math.random() * 3)];
      let result = 'lose';
      let reward = -amount;

      if (choice === botChoice) {
        result = 'tie';
        reward = 0;
      } else if (
        (choice === 'rock' && botChoice === 'scissors') ||
        (choice === 'paper' && botChoice === 'rock') ||
        (choice === 'scissors' && botChoice === 'paper')
      ) {
        result = 'win';
        reward = Math.floor(amount * 1.2); // 2.2x total = bet + 1.2x bet
      }

      const newBalance = balance + reward;
      data[userId] = newBalance;
      fs.writeFileSync(path, JSON.stringify(data, null, 2));

      // Create embed
      const embed = new EmbedBuilder()
        .setColor(result === 'win' ? '#00FF00' : result === 'tie' ? '#FFFF00' : '#FF0000')
        .setTitle(`${emoji} Rock, Paper, Scissors`)
        .setDescription(
          result === 'win' ? `🎉 **${choice.toUpperCase()}** beats **${botChoice}**!` :
          result === 'tie' ? `🤝 It's a tie! Both chose **${choice}**.` :
          `😔 **${botChoice.toUpperCase()}** beats **${choice}**.`
        )
        .addFields(
          { name: '🎯 Your Choice', value: choice.charAt(0).toUpperCase() + choice.slice(1), inline: true },
          { name: '🤖 Bot Choice', value: botChoice.charAt(0).toUpperCase() + botChoice.slice(1), inline: true },
          { name: '💸 Bet', value: `${amount.toLocaleString()}`, inline: true },
          { name: '🏆 Payout', value: `${reward >= 0 ? '+' : ''}${reward.toLocaleString()}`, inline: true },
          { name: '💰 Balance', value: `${newBalance.toLocaleString()}`, inline: true }
        )
        .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
        .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() })
        .setTimestamp();

      await interaction.editReply({ content: null, embeds: [embed] });
    } catch (error) {
      console.error('RPS slash command error:', error);
      await interaction.reply({ content: 'An error occurred!', ephemeral: true });
    }
  },
};