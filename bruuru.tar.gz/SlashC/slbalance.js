const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = './Balance.json';
const emoji = '';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('balance')
    .setDescription('Check your Thunder Coin balance')
    .addUserOption(option => option.setName('user').setDescription('User to check').setRequired(false)),

  async execute(interaction) {
    const user = interaction.options.getUser('user') || interaction.user;
    const data = JSON.parse(fs.readFileSync(path, 'utf8'));
    const coins = data[user.id] ?? 0;

    const embed = new EmbedBuilder()
      .setColor('#FFD700')
      .setTitle(`${emoji} Balance`)
      .setDescription(`You currently have **${coins} Thunder Coins**!`)
      .setThumbnail(user.displayAvatarURL({ dynamic: true }))
      .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() });

    await interaction.reply({ embeds: [embed] });
  }
};