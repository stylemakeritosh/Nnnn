const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = './Balance.json';
const bankPath = './Bank.json';
const emoji = '<:0_Deco_stargold:1363095379364679881>';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('bank')
    .setDescription('Manage your Thunder Coin bank balance')
    .addSubcommand(subcommand =>
      subcommand
        .setName('view')
        .setDescription('View bank balance')
        .addUserOption(option => option.setName('user').setDescription('User to check').setRequired(false))
    )
    .addSubcommand(subcommand =>
      subcommand
        .setName('transfer')
        .setDescription('Transfer Thunder Coins to bank')
        .addIntegerOption(option => option.setName('amount').setDescription('Amount to transfer').setRequired(true).setMinValue(1))
    )
    .addSubcommand(subcommand =>
      subcommand
        .setName('withdraw')
        .setDescription('Withdraw Thunder Coins from bank')
        .addIntegerOption(option => option.setName('amount').setDescription('Amount to withdraw').setRequired(true).setMinValue(1))
    ),

  async execute(interaction) {
    try {
      const subcommand = interaction.options.getSubcommand();
      const user = interaction.options.getUser('user') || interaction.user;
      let balanceData = fs.existsSync(path) ? JSON.parse(fs.readFileSync(path, 'utf8')) : {};
      let bankData = fs.existsSync(bankPath) ? JSON.parse(fs.readFileSync(bankPath, 'utf8')) : {};

      const userBalance = balanceData[user.id] ?? 0;
      const userBank = bankData[user.id] ?? 0;

      const embed = new EmbedBuilder()
        .setColor('#FFD700')
        .setThumbnail(user.displayAvatarURL({ dynamic: true }))
        .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() });

      if (subcommand === 'view') {
        embed
          .setTitle(`${emoji} Bank Balance`)
          .setDescription(`${user.username}'s bank balance: **${userBank.toLocaleString()} Thunder Coins**`)
          .addFields({ name: 'Wallet', value: `${userBalance.toLocaleString()} Thunder Coins`, inline: true });
      } else if (subcommand === 'transfer') {
        const amount = interaction.options.getInteger('amount');
        if (amount > userBalance) {
          return interaction.reply({ content: 'Insufficient Thunder Coins in wallet!', ephemeral: true });
        }
        balanceData[user.id] = (balanceData[user.id] ?? 0) - amount;
        bankData[user.id] = (bankData[user.id] ?? 0) + amount;
        fs.writeFileSync(path, JSON.stringify(balanceData, null, 2));
        fs.writeFileSync(bankPath, JSON.stringify(bankData, null, 2));
        embed
          .setTitle(`${emoji} Transfer Successful`)
          .setDescription(`Transferred **${amount.toLocaleString()} Thunder Coins** to your bank!`)
          .addFields(
            { name: 'New Wallet Balance', value: `${balanceData[user.id].toLocaleString()} Thunder Coins`, inline: true },
            { name: 'New Bank Balance', value: `${bankData[user.id].toLocaleString()} Thunder Coins`, inline: true }
          );
      } else if (subcommand === 'withdraw') {
        const amount = interaction.options.getInteger('amount');
        if (amount > userBank) {
          return interaction.reply({ content: 'Insufficient Thunder Coins in bank!', ephemeral: true });
        }
        balanceData[user.id] = (balanceData[user.id] ?? 0) + amount;
        bankData[user.id] = (bankData[user.id] ?? 0) - amount;
        fs.writeFileSync(path, JSON.stringify(balanceData, null, 2));
        fs.writeFileSync(bankPath, JSON.stringify(bankData, null, 2));
        embed
          .setTitle(`${emoji} Withdrawal Successful`)
          .setDescription(`Withdrew **${amount.toLocaleString()} Thunder Coins** from your bank!`)
          .addFields(
            { name: 'New Wallet Balance', value: `${balanceData[user.id].toLocaleString()} Thunder Coins`, inline: true },
            { name: 'New Bank Balance', value: `${bankData[user.id].toLocaleString()} Thunder Coins`, inline: true }
          );
      }

      await interaction.reply({ embeds: [embed] });
    } catch (error) {
      console.error('Bank command error:', error);
      await interaction.reply({ content: 'An error occurred!', ephemeral: true });
    }
  },
};