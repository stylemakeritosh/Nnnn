const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require('discord.js');
const emoji = '<:0_Deco_stargold:1363095379364679881>';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unlock')
    .setDescription('Unlock a channel to restore default message permissions.')
    .addChannelOption(option => option.setName('channel').setDescription('Channel to unlock (optional)')),
  async execute(interaction) {
    try {
      await interaction.deferReply();

      // Check permissions
      if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
        return interaction.editReply('❌ You need **Manage Channels** permission to use this command!');
      }

      // Get channel
      const channel = interaction.options.getChannel('channel') || interaction.channel;
      if (!channel || !channel.isTextBased()) {
        return interaction.editReply('Please select a valid text channel!');
      }

      // Unlock channel by setting SEND_MESSAGES to null (neutral)
      await channel.permissionOverwrites.edit(interaction.guild.roles.everyone, {
        SendMessages: null,
      });

      // Create embed
      const embed = new EmbedBuilder()
        .setColor('#FFD700')
        .setTitle(`${emoji} Channel Unlocked`)
        .setDescription(`🔓 **${channel.name}** has been unlocked to default permissions!`)
        .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() })
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      console.error('Unlock slash command error:', error);
      await interaction.editReply('⚠️ An error occurred while unlocking the channel!');
    }
  },
};