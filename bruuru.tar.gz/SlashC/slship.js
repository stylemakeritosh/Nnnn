const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const emoji = '<:0_Deco_stargold:1363095379364679881>';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ship')
    .setDescription('Calculate the compatibility between two users!')
    .addUserOption(option => option.setName('user1').setDescription('First user to ship').setRequired(true))
    .addUserOption(option => option.setName('user2').setDescription('Second user to ship (optional)')),
  async execute(interaction) {
    try {
      await interaction.deferReply();

      // Get users
      const user1 = interaction.options.getUser('user1');
      const user2 = interaction.options.getUser('user2') || interaction.user;

      // Validate input
      if (user1.id === user2.id) {
        return interaction.editReply('Please select two different users to ship!');
      }

      // Generate random percentage
      const percentage = Math.floor(Math.random() * 100) + 1;

      // Determine flavor text based on percentage
      let flavorText = 'Go Make a Baby Already 🤤 💞';
      if (percentage > 80) flavorText = 'Maybe Your Meant To Be!🌹';
      else if (percentage > 50) flavorText = 'Trusted Eachother! 💖';
      else if (percentage > 20) flavorText = 'Might need some work! 💦';
      else flavorText = 'Better luck next time! 💔';

      // Create embed
      const embed = new EmbedBuilder()
        .setColor('#FFD700')
        .setTitle(`${emoji} Love Calculator`)
        .setDescription(flavorText)
        .addFields({
          name: '💑 Compatibility',
          value: `**${user1.username}** & **${user2.username}**: **${percentage}%**`,
          inline: false,
        })
        .setThumbnail(interaction.guild.iconURL({ dynamic: true }) || 'https://cdn.discordapp.com/embed/avatars/0.png')
        .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() })
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      console.error('Ship slash command error:', error);
      await interaction.editReply('⚠️ An error occurred while calculating compatibility!');
    }
  },
};