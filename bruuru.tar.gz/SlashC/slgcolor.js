const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = './Balance.json';
const emoji = '<:0_Deco_stargold:1363095379364679881>';

const colors = ['red', 'blue', 'green', 'yellow', 'purple', 'orange', 'pink', 'black', 'white'];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('gcolor')
    .setDescription('Bet Thunder Coins on a color. Win 2x if your color is among the 3 success colors!')
    .addStringOption(option =>
      option
        .setName('color')
        .setDescription('The color to bet on')
        .setRequired(true)
        .addChoices(...colors.map(color => ({ name: color, value: color })))
    )
    .addIntegerOption(option =>
      option
        .setName('amount')
        .setDescription('Thunder Coins to bet')
        .setRequired(true)
        .setMinValue(1)
    ),
  async execute(interaction) {
    try {
      await interaction.deferReply();

      const colorInput = interaction.options.getString('color').toLowerCase();
      const amount = interaction.options.getInteger('amount');

      // Load balance data
      let balanceData = fs.existsSync(path) ? JSON.parse(fs.readFileSync(path, 'utf8')) : {};
      const userBalance = balanceData[interaction.user.id] ?? 0;

      if (amount > userBalance) {
        return interaction.editReply('🚫 Insufficient Thunder Coins!');
      }

      // Animation sequence
      const animationMsg = await interaction.channel.send('🎨 Shuffling colors...');
      await new Promise(resolve => setTimeout(resolve, 1000));
      await animationMsg.edit('🌟 Picking success colors...');
      await new Promise(resolve => setTimeout(resolve, 1000));
      await animationMsg.edit('🎉 Revealing results!');

      // Randomly select 9 colors (with replacement)
      const rolledColors = Array.from({ length: 9 }, () => colors[Math.floor(Math.random() * colors.length)]);
      // Randomly select 3 unique success colors
      const successColors = [];
      const rolledCopy = [...rolledColors];
      for (let i = 0; i < 3; i++) {
        const randomIndex = Math.floor(Math.random() * rolledCopy.length);
        successColors.push(rolledCopy.splice(randomIndex, 1)[0]);
      }

      // Determine win condition
      const isWin = successColors.includes(colorInput);
      const reward = isWin ? amount * 2 : 0;

      // Update balance
      balanceData[interaction.user.id] = userBalance - amount + reward;
      fs.writeFileSync(path, JSON.stringify(balanceData, null, 2));

      // Create embed
      const embed = new EmbedBuilder()
        .setColor(isWin ? '#00FF00' : '#FF0000')
        .setTitle(`${emoji} Color Guess Outcome`)
        .setDescription(
          isWin
            ? `🎉 **${colorInput}** was a hit! You won **${reward.toLocaleString()}** Thunder Coins!`
            : `😔 **${colorInput}** missed. You lost **${amount.toLocaleString()}** Thunder Coins.`
        )
        .addFields(
          {
            name: 'Your Bet',
            value: `**Color**: ${colorInput.charAt(0).toUpperCase() + colorInput.slice(1)}\n**Amount**: ${amount.toLocaleString()} ${emoji}`,
            inline: true
          },
          {
            name: 'Results',
            value: `**Rolled**: ${rolledColors.join(', ')}\n**Success**: **${successColors.join(', ')}**`,
            inline: true
          },
          {
            name: 'Balance',
            value: `${balanceData[interaction.user.id].toLocaleString()} ${emoji}`,
            inline: true
          }
        )
        .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
        .setFooter({ text: `Played in ${interaction.guild.name}`, iconURL: interaction.guild.iconURL() })
        .setTimestamp();

      await animationMsg.delete();
      interaction.editReply({ embeds: [embed] });
    } catch (error) {
      console.error('Gcolor slash command error:', error);
      interaction.editReply('⚠️ An error occurred!');
    }
  },
};