const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = './Balance.json';
const emoji = '<:0_Deco_stargold:1363095379364679881>';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('highlow')
    .setDescription('Bet Thunder Coins for a 30% chance to triple your bet')
    .addIntegerOption(option =>
      option.setName('amount').setDescription('Amount to bet').setRequired(true).setMinValue(1)
    ),

  async execute(interaction) {
    try {
      const amount = interaction.options.getInteger('amount');

      let balanceData = fs.existsSync(path) ? JSON.parse(fs.readFileSync(path, 'utf8')) : {};
      const userBalance = balanceData[interaction.user.id] ?? 0;

      if (amount > userBalance) {
        return interaction.reply({ content: 'Insufficient Thunder Coins!', ephemeral: true });
      }

      // Animation sequence
      await interaction.reply('Are You Lucky?... 🎲');
      await new Promise(resolve => setTimeout(resolve, 1000));
      await interaction.editReply('Almost there... ⚡');
      await new Promise(resolve => setTimeout(resolve, 1000));
      await interaction.editReply('Result!');

      const winChance = Math.random();
      const isWin = winChance <= 0.30; // 30% chance to win (increased from 25%)
      const reward = isWin ? amount * 3 : 0;

      balanceData[interaction.user.id] = userBalance - amount + reward;
      fs.writeFileSync(path, JSON.stringify(balanceData, null, 2));

      const embed = new EmbedBuilder()
        .setColor(isWin ? '#00FF00' : '#FF0000')
        .setTitle(`${emoji} High-Low Result`)
        .setDescription(
          isWin
            ? `Congratulations! You won **${reward.toLocaleString()} Thunder Coins** (3x your bet)!`
            : `Sorry, you lost **${amount.toLocaleString()} Thunder Coins**. Better luck next time!`
        )
        .addFields(
          { name: 'Bet Amount', value: `${amount.toLocaleString()} Thunder Coins`, inline: true },
          { name: 'New Balance', value: `${balanceData[interaction.user.id].toLocaleString()} Thunder Coins`, inline: true }
        )
        .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
        .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() });

      await interaction.editReply({ content: null, embeds: [embed] });
    } catch (error) {
      console.error('Highlow command error:', error);
      await interaction.reply({ content: 'An error occurred!', ephemeral: true });
    }
  },
};