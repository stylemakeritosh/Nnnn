require('dotenv').config(); // Load environment variables from .env

const { Client, Collection, GatewayIntentBits, ActivityType, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const settings = require('./settings.js');
const shopItems = require('./shopItems.js'); // Import shared shop items

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers, // Added for role management
  ],
});

// Handle unexpected errors and crashes
process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
});

process.on('uncaughtException', (err) => {
  console.error('Uncaught Exception:', err);
});

process.on('uncaughtExceptionMonitor', (err) => {
  console.error('Uncaught Exception (Monitored):', err);
});

// Collections to store commands
client.prefixCommands = new Collection();
client.slashCommands = new Collection();

// Load Prefix Commands
const prefixCommandFiles = fs.readdirSync('./PrefixC').filter(file => file.endsWith('.js'));
for (const file of prefixCommandFiles) {
  const command = require(`./PrefixC/${file}`);
  client.prefixCommands.set(command.name, command);
}

// Load Slash Commands
const slashCommandFiles = fs.readdirSync('./SlashC').filter(file => file.endsWith('.js'));
const slashCommands = [];
for (const file of slashCommandFiles) {
  const command = require(`./SlashC/${file}`);
  client.slashCommands.set(command.data.name, command);
  slashCommands.push(command.data.toJSON());
}

// Register Slash Commands
const { REST } = require('@discordjs/rest');
const { Routes } = require('discord.js');
const rest = new REST({ version: '10' }).setToken(process.env.TOKEN);

client.once('ready', async () => {
  console.log(`Logged in as ${client.user.tag}!`);

  // Set bot status
  client.user.setPresence({
    activities: [{ name: settings.status.text, type: ActivityType[settings.status.type] }],
    status: settings.status.status,
  });

  // Register slash commands globally
  try {
    await rest.put(Routes.applicationCommands(client.user.id), { body: slashCommands });
    console.log('Successfully registered slash commands globally.');
  } catch (error) {
    console.error('Error registering slash commands:', error);
  }

  // Start leaderboard prize checker
  setInterval(async () => {
    try {
      if (!fs.existsSync('./prize.json')) return;
      const prizeData = JSON.parse(fs.readFileSync('./prize.json', 'utf8'));

      for (const guildId in prizeData) {
        const guildPrize = prizeData[guildId];
        if (!guildPrize.nextAwardTime || !guildPrize.guildId || !guildPrize.roleId) continue;

        const now = Date.now();
        if (now >= guildPrize.nextAwardTime) {
          // Read balance data
          const balanceData = fs.existsSync('./Balance.json') ? JSON.parse(fs.readFileSync('./Balance.json', 'utf8')) : {};

          // Get top user
          let leaderboard = Object.entries(balanceData)
            .map(([userId, coins]) => ({ userId, coins }))
            .sort((a, b) => b.coins - a.coins);

          // Filter for server members
          const guild = client.guilds.cache.get(guildPrize.guildId);
          if (!guild) continue;

          leaderboard = leaderboard.filter(entry => guild.members.cache.has(entry.userId));
          const topUser = leaderboard[0];

          if (topUser) {
            const member = await guild.members.fetch(topUser.userId).catch(() => null);
            if (member) {
              // Award role
              await member.roles.add(guildPrize.roleId).catch(err => console.error(`Error assigning role in guild ${guildId}:`, err));

              // Notify user
              const embed = new EmbedBuilder()
                .setColor('#FFD700')
                .setTitle('🏆 Leaderboard Prize Awarded!')
                .setDescription(`Congratulations, ${member}! You've secured the top spot on the Thunder Coin Leaderboard and received the prize role!`)
                .addFields(
                  { name: '🎁 Prize Role', value: `<@&${guildPrize.roleId}>`, inline: true },
                  { name: '💰 Your Balance', value: `${topUser.coins.toLocaleString()} Thunder•coins`, inline: true }
                )
                .setThumbnail(guild.iconURL({ dynamic: true }))
                .setFooter({ text: guild.name, iconURL: guild.iconURL() })
                .setTimestamp();

              await member.send({ embeds: [embed] }).catch(() => {
                guild.systemChannel?.send({ content: `${member}, please enable DMs to receive your prize notification!`, embeds: [embed] });
              });
            }
          }

          // Update next award time
          guildPrize.nextAwardTime = now + guildPrize.intervalHours * 60 * 60 * 1000;
          prizeData[guildId] = guildPrize;
          fs.writeFileSync('./prize.json', JSON.stringify(prizeData, null, 2));
        }
      }
    } catch (error) {
      console.error('Leaderboard prize checker error:', error);
    }
  }, 60 * 1000); // Check every minute
});

// Load server-specific prefixes
function getGuildPrefix(guildId) {
  try {
    if (fs.existsSync('./Server.json')) {
      const serverData = JSON.parse(fs.readFileSync('./Server.json', 'utf8'));
      return serverData[guildId] || settings.prefix;
    }
    return settings.prefix;
  } catch (error) {
    console.error('Error loading server prefix:', error);
    return settings.prefix;
  }
}

// Handle Prefix Commands
client.on('messageCreate', async message => {
  if (message.author.bot || !message.guild) return;

  const guildPrefix = getGuildPrefix(message.guild.id);
  const normalizedPrefix = guildPrefix.toLowerCase();
  const messageContent = message.content.trim();

  // Check if message starts with the prefix (case-insensitive, allowing trailing space)
  if (!messageContent.toLowerCase().startsWith(normalizedPrefix)) return;

  // Extract command and args, accounting for possible space after prefix
  const prefixLength = messageContent.toLowerCase().indexOf(normalizedPrefix) + normalizedPrefix.length;
  const contentAfterPrefix = messageContent.slice(prefixLength).trim();
  const args = contentAfterPrefix.split(/ +/);
  const commandName = args.shift().toLowerCase();

  const command = client.prefixCommands.get(commandName);
  if (!command) return;

  try {
    await command.execute(message, args);
  } catch (error) {
    console.error('Error executing prefix command:', error);
    message.reply('There was an error executing that command!');
  }
});

// Handle Slash Commands
client.on('interactionCreate', async interaction => {
  if (!interaction.isChatInputCommand()) return;

  const command = client.slashCommands.get(interaction.commandName);
  if (!command) return;

  try {
    await command.execute(interaction);
  } catch (error) {
    console.error('Error executing slash command:', error);
    await interaction.reply({ content: 'There was an error executing that command!', ephemeral: true });
  }
});

// Handle Passive Item Effects
const balancePath = './Balance.json';
const invPath = './inventory.json';
const emoji = '<:0_Deco_stargold:1363095379364679881>';
const shopItemNames = shopItems.map(item => item.name);
const itemCooldowns = new Map(); // Unified cooldown map for all items

function getWeightedRandomItem() {
  const totalWeight = shopItems.reduce((sum, item) => sum + (1 / item.price), 0);
  let random = Math.random() * totalWeight;
  for (const item of shopItems) {
    random -= 1 / item.price;
    if (random <= 0) return item.name;
  }
  return shopItems[shopItems.length - 1].name;
}

client.on('messageCreate', async message => {
  if (message.author.bot || !message.guild) return;

  try {
    let balanceData = fs.existsSync(balancePath) ? JSON.parse(fs.readFileSync(balancePath, 'utf8')) : {};
    let invData = fs.existsSync(invPath) ? JSON.parse(fs.readFileSync(invPath, 'utf8')) : {};
    const userInv = invData[message.author.id] || {};
    const now = Date.now();
    const cooldownDuration = 2000; // 2-second cooldown for all items
    let updated = false;

    // Base embed configuration
    const embed = new EmbedBuilder()
      .setColor('#FFD700')
      .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
      .setFooter({ text: `ThunderHub | ${message.guild.name}`, iconURL: message.guild.iconURL({ dynamic: true }) })
      .setTimestamp();

    // Metavision
    if (userInv['Metavision'] > 0) {
      const lastTriggered = itemCooldowns.get(`${message.author.id}_Metavision`) || 0;
      if (now - lastTriggered >= cooldownDuration && Math.random() < 0.02) {
        const randomItem = shopItemNames[Math.floor(Math.random() * shopItemNames.length)];
        invData[message.author.id] = invData[message.author.id] || {};
        invData[message.author.id][randomItem] = (invData[message.author.id][randomItem] || 0) + 1;
        embed
          .setTitle(`${emoji} Metavision Vision`)
          .setDescription(`✨ Your **Metavision** has glimpsed the future, granting you a **${randomItem}**!`)
          .addFields(
            { name: '🎁 Reward', value: `**${randomItem}** x1`, inline: true },
            { name: '📊 Rarity', value: 'Legendary', inline: true },
            { name: 'ℹ️ Info', value: 'Check your inventory with `/inventory`.' }
          );
        updated = true;
        itemCooldowns.set(`${message.author.id}_Metavision`, now);
        message.author.send({ embeds: [embed] }).catch(() => message.reply('Please enable DMs to receive passive item rewards!'));
      }
    }

    // Yo Michael
    const yoMichaelCount = userInv['Yo Michael'] || 0;
    if (yoMichaelCount > 0) {
      const yoMichaelChance = 0.15 * yoMichaelCount;
      const lastTriggered = itemCooldowns.get(`${message.author.id}_YoMichael`) || 0;
      if (now - lastTriggered >= cooldownDuration && Math.random() < yoMichaelChance) {
        const randomItem = getWeightedRandomItem();
        invData[message.author.id] = invData[message.author.id] || {};
        invData[message.author.id][randomItem] = (invData[message.author.id][randomItem] || 0) + 1;
        embed
          .setTitle(`${emoji} Yo Michael Fortune`)
          .setDescription(`🌟 **Yo Michael** has smiled upon you, gifting a **${randomItem}**!`)
          .addFields(
            { name: '🎁 Reward', value: `**${randomItem}** x1`, inline: true },
            { name: '📊 Rarity', value: 'Mythical', inline: true },
            { name: 'ℹ️ Info', value: 'Browse the shop with `/shop`.' }
          );
        updated = true;
        itemCooldowns.set(`${message.author.id}_YoMichael`, now);
        message.author.send({ embeds: [embed] }).catch(() => message.reply('Please enable DMs to receive passive item rewards!'));
      }
    }

    // Ego Prime
    const egoPrimeCount = userInv['Ego Prime'] || 0;
    if (egoPrimeCount > 0) {
      const egoChance = 0.10 * egoPrimeCount;
      const lastTriggered = itemCooldowns.get(`${message.author.id}_EgoPrime`) || 0;
      if (now - lastTriggered >= cooldownDuration && Math.random() < egoChance) {
        const coins = 10000;
        balanceData[message.author.id] = (balanceData[message.author.id] || 0) + coins;
        embed
          .setTitle(`${emoji} Ego Prime Surge`)
          .setDescription(`⚡ **Ego Prime** has unleashed a surge of **${coins.toLocaleString()} Thunder Coins**!`)
          .addFields(
            { name: '💰 Reward', value: `${coins.toLocaleString()} Thunder Coins`, inline: true },
            { name: '📈 Balance', value: `${balanceData[message.author.id].toLocaleString()} Thunder Coins`, inline: true },
            { name: 'ℹ️ Info', value: 'Spend your coins with `/shop`.' }
          );
        updated = true;
        itemCooldowns.set(`${message.author.id}_EgoPrime`, now);
        message.author.send({ embeds: [embed] }).catch(() => message.reply('Please enable DMs to receive passive item rewards!'));
      }
    }

    // Kaiser Kiss
    const kaiserKissCount = userInv['Kaiser Kiss'] || 0;
    if (kaiserKissCount > 0) {
      const kaiserChance = 0.05 * kaiserKissCount;
      const lastTriggered = itemCooldowns.get(`${message.author.id}_KaiserKiss`) || 0;
      if (now - lastTriggered >= cooldownDuration && Math.random() < kaiserChance) {
        const coins = Math.floor(Math.random() * (10000 - 5000 + 1)) + 5000;
        balanceData[message.author.id] = (balanceData[message.author.id] || 0) + coins;
        embed
          .setTitle(`${emoji} Kaiser Kiss Blessing`)
          .setDescription(`💋 The **Kaiser Kiss** has bestowed **${coins.toLocaleString()} Thunder Coins** upon you!`)
          .addFields(
            { name: '💰 Reward', value: `${coins.toLocaleString()} Thunder Coins`, inline: true },
            { name: '📈 Balance', value: `${balanceData[message.author.id].toLocaleString()} Thunder Coins`, inline: true },
            { name: 'ℹ️ Info', value: 'Check your balance with `/balance`.' }
          );
        updated = true;
        itemCooldowns.set(`${message.author.id}_KaiserKiss`, now);
        message.author.send({ embeds: [embed] }).catch(() => message.reply('Please enable DMs to receive passive item rewards!'));
      }
    }

    if (updated) {
      fs.writeFileSync(balancePath, JSON.stringify(balanceData, null, 2));
      fs.writeFileSync(invPath, JSON.stringify(invData, null, 2));
    }
  } catch (error) {
    console.error('Message listener error:', error);
  }
});

// Login to Discord
client.login(process.env.TOKEN);