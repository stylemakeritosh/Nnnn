const fs = require('fs');
const path = './staffs.json';

class Staffs {
  static getStaffLogChannel(guildId) {
    try {
      if (!fs.existsSync(path)) {
        fs.writeFileSync(path, '{}', 'utf-8');
      }
      const data = JSON.parse(fs.readFileSync(path, 'utf-8'));
      return data[guildId] || null;
    } catch (error) {
      console.error('Error reading staff log channel:', error);
      return null;
    }
  }

  static setStaffLogChannel(guildId, channelId) {
    try {
      if (!fs.existsSync(path)) {
        fs.writeFileSync(path, '{}', 'utf-8');
      }
      const data = JSON.parse(fs.readFileSync(path, 'utf-8'));
      data[guildId] = channelId;
      fs.writeFileSync(path, JSON.stringify(data, null, 2), 'utf-8');
    } catch (error) {
      console.error('Error setting staff log channel:', error);
    }
  }
}

module.exports = Staffs;