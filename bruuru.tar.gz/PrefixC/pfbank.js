const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = './Balance.json';
const bankPath = './Bank.json';
const emoji = '<:0_Deco_stargold:1363095379364679881>';

module.exports = {
  name: 'bank',
  description: 'Manage your Thunder Coin bank balance',
  usage: 'bank [t/w] [amount/@user]',
  execute(message, args) {
    try {
      let user = message.author;
      let balanceData = fs.existsSync(path) ? JSON.parse(fs.readFileSync(path, 'utf8')) : {};
      let bankData = fs.existsSync(bankPath) ? JSON.parse(fs.readFileSync(bankPath, 'utf8')) : {};

      if (args[0] && message.mentions.users.size) {
        user = message.mentions.users.first();
      }

      const userBalance = balanceData[user.id] ?? 0;
      const userBank = bankData[user.id] ?? 0;

      const embed = new EmbedBuilder()
        .setColor('#FFD700')
        .setThumbnail(user.displayAvatarURL({ dynamic: true }))
        .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() });

      if (!args[0] || message.mentions.users.size) {
        embed
          .setTitle(`${emoji} Bank Balance`)
          .setDescription(`${user.username}'s bank balance: **${userBank.toLocaleString()} Thunder Coins**`)
          .addFields({ name: 'Wallet', value: `${userBalance.toLocaleString()} Thunder Coins`, inline: true });
      } else if (args[0].toLowerCase() === 't' || args[0].toLowerCase() === 'transfer') {
        const amount = parseInt(args[1]);
        if (isNaN(amount) || amount <= 0) {
          return message.reply('Please provide a valid amount!');
        }
        if (amount > userBalance) {
          return message.reply('Insufficient Thunder Coins in wallet!');
        }
        balanceData[user.id] = (balanceData[user.id] ?? 0) - amount;
        bankData[user.id] = (bankData[user.id] ?? 0) + amount;
        fs.writeFileSync(path, JSON.stringify(balanceData, null, 2));
        fs.writeFileSync(bankPath, JSON.stringify(bankData, null, 2));
        embed
          .setTitle(`${emoji} Transfer Successful`)
          .setDescription(`Transferred **${amount.toLocaleString()} Thunder Coins** to your bank!`)
          .addFields(
            { name: 'New Thunder Coin Balance', value: `${balanceData[user.id].toLocaleString()} Thunder Coins`, inline: true },
            { name: 'New Bank Balance', value: `${bankData[user.id].toLocaleString()} Thunder Coins`, inline: true }
          );
      } else if (args[0].toLowerCase() === 'w' || args[0].toLowerCase() === 'withdraw') {
        const amount = parseInt(args[1]);
        if (isNaN(amount) || amount <= 0) {
          return message.reply('Please provide a valid amount!');
        }
        if (amount > userBank) {
          return message.reply('Insufficient Thunder Coins in bank!');
        }
        balanceData[user.id] = (balanceData[user.id] ?? 0) + amount;
        bankData[user.id] = (bankData[user.id] ?? 0) - amount;
        fs.writeFileSync(path, JSON.stringify(balanceData, null, 2));
        fs.writeFileSync(bankPath, JSON.stringify(bankData, null, 2));
        embed
          .setTitle(`${emoji} Withdrawal Successful`)
          .setDescription(`Withdrew **${amount.toLocaleString()} Thunder Coins** from your bank!`)
          .addFields(
            { name: 'New Wallet Balance', value: `${balanceData[user.id].toLocaleString()} Thunder Coins`, inline: true },
            { name: 'New Bank Balance', value: `${bankData[user.id].toLocaleString()} Thunder Coins`, inline: true }
          );
      } else {
        return message.reply('Invalid subcommand! Use `bank`, `bank @user`, `bank t <amount>`, or `bank w <amount>`.');
      }

      message.channel.send({ embeds: [embed] });
    } catch (error) {
      console.error('Bank prefix command error:', error);
      message.reply('An error occurred!');
    }
  },
};