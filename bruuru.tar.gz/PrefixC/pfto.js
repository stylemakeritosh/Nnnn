const { EmbedBuilder, PermissionsBitField } = require('discord.js');
const emoji = '<:0_Deco_stargold:1363095379364679881>';

module.exports = {
  name: 'to',
  aliases: ['timeout'],
  description: 'Timeout a user for 1s to 4w.',
  usage: 'to @user <duration> [reason]',
  async execute(message, args) {
    try {
      if (!message.guild.members.me.permissions.has(PermissionsBitField.Flags.ModerateMembers)) {
        return message.reply('⚠️ I lack permission to timeout members!');
      }
      if (!message.member.permissions.has(PermissionsBitField.Flags.ModerateMembers)) {
        return message.reply('⚠️ You lack permission to timeout members!');
      }

      const target = message.mentions.members.first();
      if (!target) return message.reply('Please mention a user to timeout!');
      if (target.id === message.author.id) return message.reply('You cannot timeout yourself!');
      if (target.id === message.client.user.id) return message.reply('You cannot timeout me!');

      const userHighestRole = message.member.roles.highest;
      const targetHighestRole = target.roles.highest;
      if (userHighestRole.position <= targetHighestRole.position) {
        return message.reply('You cannot timeout users with equal or higher roles!');
      }

      if (!target.moderatable) {
        return message.reply('I cannot timeout this user! They may be the server owner or have higher permissions.');
      }

      const durationInput = args[1];
      if (!durationInput) return message.reply('Please specify a duration (e.g., 30s, 1m, 1h, 1d, 1w)!');

      const timeUnits = { s: 1, m: 60, h: 3600, d: 86400, w: 604800 };
      const match = durationInput.match(/^(\d+)([smhdw])$/);
      if (!match) return message.reply('Invalid duration! Use 1s to 4w.');

      const [_, value, unit] = match;
      const seconds = parseInt(value) * timeUnits[unit];
      if (seconds < 1 || seconds > 4 * 604800) {
        return message.reply('Duration must be 1s to 4w!');
      }

      const reason = args.slice(2).join(' ') || 'No reason provided';
      await target.timeout(seconds * 1000, `Timed out by ${message.author.tag}: ${reason}`);

      const embed = new EmbedBuilder()
        .setColor('#FF5555')
        .setTitle(`${emoji} Timeout Applied`)
        .addFields(
          { name: 'User', value: `<@${target.id}>`, inline: true },
          { name: 'Duration', value: durationInput, inline: true },
          { name: 'Reason', value: reason, inline: true }
        )
        .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() || 'https://cdn.discordapp.com/embed/avatars/0.png' })
        .setTimestamp();

      await message.channel.send({ content: `<@${target.id}> has been timed out!`, embeds: [embed] });
    } catch (error) {
      console.error('Timeout prefix command error:', error);
      await message.reply('⚠️ Error timing out user!');
    }
  },
};