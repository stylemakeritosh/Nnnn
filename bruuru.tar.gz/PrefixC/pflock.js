const { EmbedBuilder, PermissionsBitField } = require('discord.js');
const emoji = '<:0_Deco_stargold:1363095379364679881>';

module.exports = {
  name: 'lock',
  description: 'Lock a channel to prevent messages.',
  usage: 'lock [#channel]',
  async execute(message, args) {
    try {
      // Check permissions
      if (!message.member.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
        return message.reply('❌ You need **Manage Channels** permission to use this command!');
      }

      // Get channel
      const channel = args[0] ? message.mentions.channels.first() : message.channel;
      if (!channel || !channel.isTextBased()) {
        return message.reply('Please mention a valid text channel or use in a text channel!');
      }

      // Lock channel
      await channel.permissionOverwrites.edit(message.guild.roles.everyone, {
        SendMessages: false,
      });

      // Create embed
      const embed = new EmbedBuilder()
        .setColor('#FFD700')
        .setTitle(`${emoji} Channel Locked`)
        .setDescription(`🔒 **${channel.name}** has been locked!`)
        .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() })
        .setTimestamp();

      await message.channel.send({ embeds: [embed] });
    } catch (error) {
      console.error('Lock prefix command error:', error);
      await message.reply('⚠️ An error occurred while locking the channel!');
    }
  },
};