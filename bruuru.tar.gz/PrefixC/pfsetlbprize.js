const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const fs = require('fs');
const path = './prize.json';

module.exports = {
  name: 'setlbprize',
  description: 'Set the leaderboard prize role and time interval. Usage: setlbprize <role name> [hours]',
  async execute(message, args) {
    try {
      // Check if user has Administrator permissions
      if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
        return message.reply({
          content: 'You need Administrator permissions to use this command.',
          ephemeral: true,
        });
      }

      // Validate arguments
      if (!args[0]) {
        return message.reply({
          content: 'Please provide a role name. Usage: setlbprize <role name> [hours]',
          ephemeral: true,
        });
      }

      const roleName = args.slice(0, -1).join(' ') || args[0];
      const hours = parseInt(args[args.length - 1]) || 24;
      if (isNaN(hours)) args.pop(); // Remove invalid hours argument
      const nextAwardTime = Date.now() + hours * 60 * 60 * 1000;

      // Find role by name (case-insensitive, partial match)
      const role = message.guild.roles.cache.find(r => 
        r.name.toLowerCase().includes(roleName.toLowerCase())
      ) || message.guild.roles.cache.find(r => 
        r.name.toLowerCase() === roleName.toLowerCase()
      );

      if (!role) {
        return message.reply({
          content: `No role found matching "${roleName}". Please check the role name and try again.`,
          ephemeral: true,
        });
      }

      // Check if role is higher than user's highest role
      const userHighestRole = message.member.roles.highest;
      if (role.position >= userHighestRole.position) {
        return message.reply({
          content: 'You cannot set a prize role that is equal to or higher than your highest role.',
          ephemeral: true,
        });
      }

      // Validate role
      if (!role.editable) {
        return message.reply({
          content: 'I cannot assign this role. Please ensure my permissions are set correctly and the role is below my highest role.',
          ephemeral: true,
        });
      }

      // Load existing prize data
      let prizeData = {};
      if (fs.existsSync(path)) {
        prizeData = JSON.parse(fs.readFileSync(path));
      }

      // Update or set prize data for this guild
      prizeData[message.guild.id] = {
        roleId: role.id,
        guildId: message.guild.id,
        intervalHours: hours,
        nextAwardTime,
      };

      // Save updated prize data
      fs.writeFileSync(path, JSON.stringify(prizeData, null, 2));

      // Create embed
      const embed = new EmbedBuilder()
        .setColor('#FFD700')
        .setTitle('🏆 Leaderboard Prize Set')
        .setDescription(`The leaderboard prize has been configured successfully! ${prizeData[message.guild.id] ? 'Previous prize replaced.' : ''}`)
        .addFields(
          { name: '🎁 Prize Role', value: `<@&${role.id}>`, inline: true },
          { name: '⏰ Interval', value: `${hours} hours`, inline: true },
          { name: '📅 Next Award', value: `<t:${Math.floor(nextAwardTime / 1000)}:R>`, inline: false }
        )
        .setThumbnail(message.guild.iconURL({ dynamic: true }))
        .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() })
        .setTimestamp();

      await message.reply({ embeds: [embed] });
    } catch (error) {
      console.error('Set leaderboard prize error:', error);
      await message.reply({
        content: 'An error occurred while setting the leaderboard prize.',
        ephemeral: true,
      });
    }
  },
};