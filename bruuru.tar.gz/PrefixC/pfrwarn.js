const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const warnsPath = './warns.json';
const emoji = '<:0_Deco_stargold:1363095379364679881>';

module.exports = {
  name: 'rwarn',
  description: 'Remove a specific warning from a user',
  usage: 'rwarn @user <warnId>',
  permissions: ['ModerateMembers'],
  async execute(message, args) {
    try {
      // Check permissions
      if (!message.member.permissions.has('ModerateMembers')) {
        return message.reply('⚠️ You need the `Moderate Members` permission to use this command!');
      }
      if (!message.guild.members.me.permissions.has('ModerateMembers')) {
        return message.reply('⚠️ I need the `Moderate Members` permission to remove warnings!');
      }

      // Check if no arguments provided
      if (!args.length) {
        return message.reply(`⚠️ Usage: \`${this.usage}\``);
      }

      // Get user
      const user = message.mentions.users.first();
      if (!user) {
        return message.reply('⚠️ Please mention a valid user!');
      }
      if (user.bot) {
        return message.reply('⚠️ You cannot remove warnings from bots!');
      }

      // Get warn ID
      const warnId = parseInt(args[1]);
      if (isNaN(warnId) || warnId < 1) {
        return message.reply('⚠️ Please provide a valid warning ID!');
      }

      // Read warns data
      const warnsData = fs.existsSync(warnsPath) ? JSON.parse(fs.readFileSync(warnsPath, 'utf8')) : {};
      const guildWarns = warnsData[message.guild.id] || {};
      const userWarns = guildWarns[user.id] || [];

      // Find and remove warning
      const warnIndex = userWarns.findIndex(w => w.id === warnId);
      if (warnIndex === -1) {
        return message.reply(`⚠️ Warning #${warnId} not found for ${user.tag}!`);
      }

      const [removedWarn] = userWarns.splice(warnIndex, 1);

      // Reassign IDs to maintain sequential order
      userWarns.forEach((warn, index) => (warn.id = index + 1));

      // Update warns data
      if (userWarns.length > 0) {
        guildWarns[user.id] = userWarns;
      } else {
        delete guildWarns[user.id];
      }
      warnsData[message.guild.id] = guildWarns;
      fs.writeFileSync(warnsPath, JSON.stringify(warnsData, null, 2));

      // Create embed
      const embed = new EmbedBuilder()
        .setColor('#FFD700')
        .setTitle(`${emoji} Warning Removed`)
        .setDescription(`Removed warning #${warnId} from **${user.tag}**!`)
        .addFields(
          { name: 'Reason', value: removedWarn.reason, inline: true },
          { name: 'Remaining Warnings', value: `${userWarns.length}`, inline: true }
        )
        .setThumbnail(message.guild.iconURL({ dynamic: true }) || 'https://cdn.discordapp.com/embed/avatars/0.png')
        .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() })
        .setTimestamp();

      // Send message with user mention outside embed
      await message.channel.send({ content: `<@${user.id}>`, embeds: [embed] });
    } catch (error) {
      console.error('Rwarn prefix command error:', error);
      await message.reply('⚠️ An error occurred while removing the warning!');
    }
  },
};