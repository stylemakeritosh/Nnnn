const { EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle, PermissionsBitField } = require('discord.js');
const fs = require('fs');
const shopItems = require('../shopItems.js'); // Import shared shop items
const balancePath = './Balance.json';
const invPath = './inventory.json';
const bankPath = './Bank.json';
const emoji = '<:0_Deco_stargold:1363095379364679881>';

module.exports = {
  name: 'panel',
  description: 'Admin panel to manage balances and inventories',
  async execute(message) {
    // List of allowed user IDs
    const allowedUsers = [
      '1029672039604289566', // Bot owner ID
      '1321660546931626017', // Additional allowed user ID
    ];

    // Check if the user is in the allowed list
    if (!allowedUsers.includes(message.author.id)) {
      return message.reply('You do not have permission to use this command!');
    }

    // 2-second delay before loading panel
    await new Promise(resolve => setTimeout(resolve, 2000));

    const embed = new EmbedBuilder()
      .setColor('#FFD700')
      .setTitle(`${emoji} Admin Panel`)
      .setDescription('Select an action from the menu or use the buttons below.')
      .setThumbnail(message.guild.iconURL())
      .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() });

    // Unique custom ID for each user's panel
    const customId = `admin_panel_${message.author.id}_${Date.now()}`;

    const selectMenu = new StringSelectMenuBuilder()
      .setCustomId(customId)
      .setPlaceholder('Choose an action')
      .addOptions([
        { label: 'Edit Balance', value: 'edit_balance', description: 'Edit a user\'s balance' },
        { label: 'Add Item', value: 'add_item', description: 'Add an item to your inventory' },
        { label: 'Remove Balance', value: 'remove_balance', description: 'Remove a user\'s balance' },
        { label: 'Global Cash Reset', value: 'global_reset', description: 'Reset all balances (Owner only)' },
        { label: 'Remove Item', value: 'remove_item', description: 'Remove an item from a user\'s inventory' },
        { label: 'Give Thunder Coins', value: 'give_coins', description: 'Give Thunder Coins to a user' },
        { label: 'Cancel', value: 'cancel', description: 'Close the admin panel' },
      ]);

    // Create buttons with enhanced styling
    const resetAllInvButton = new ButtonBuilder()
      .setCustomId(`reset_all_inv_${customId}`)
      .setLabel('Reset All Inventories')
      .setStyle(ButtonStyle.Danger)
      .setEmoji('🗑️');

    const resetUserInvButton = new ButtonBuilder()
      .setCustomId(`reset_user_inv_${customId}`)
      .setLabel('Reset User Inventory')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('🧹');

    const resetUserBankButton = new ButtonBuilder()
      .setCustomId(`reset_user_bank_${customId}`)
      .setLabel('Reset User Bank')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('🏦');

    const resetGlobalBankButton = new ButtonBuilder()
      .setCustomId(`reset_global_bank_${customId}`)
      .setLabel('Reset Global Bank')
      .setStyle(ButtonStyle.Danger)
      .setEmoji('💸');

    const cancelButton = new ButtonBuilder()
      .setCustomId(`cancel_${customId}`)
      .setLabel('Close Panel')
      .setStyle(ButtonStyle.Primary)
      .setEmoji('❌');

    // Organize buttons into two rows (max 5 buttons per row)
    const row1 = new ActionRowBuilder().addComponents(selectMenu);
    const row2 = new ActionRowBuilder().addComponents(
      resetAllInvButton,
      resetUserInvButton,
      resetUserBankButton,
      resetGlobalBankButton,
      cancelButton
    );

    const panelMessage = await message.channel.send({ embeds: [embed], components: [row1, row2] });

    const collector = message.channel.createMessageComponentCollector({
      filter: i => i.customId.includes(customId) && i.user.id === message.author.id,
      time: 60000, // 1-minute timeout
    });

    collector.on('collect', async (interaction) => {
      await interaction.deferReply({ ephemeral: true });

      // Reset the collector's timeout on each interaction
      collector.resetTimer({ time: 60000 });

      const option = interaction.isStringSelectMenu() ? interaction.values[0] : interaction.customId.split('_')[0];

      // Handle button interactions
      if (interaction.isButton()) {
        if (interaction.customId === `cancel_${customId}`) {
          await panelMessage.delete().catch(() => {});
          await interaction.followUp({ content: 'Admin panel closed.', ephemeral: true });
          collector.stop();
          return;
        }

        // Restrict button actions to allowed users
        if (!allowedUsers.includes(interaction.user.id)) {
          return interaction.followUp({ content: 'Only authorized users can use these buttons!', ephemeral: true });
        }

        let invData = fs.existsSync(invPath) ? JSON.parse(fs.readFileSync(invPath, 'utf8')) : {};
        let bankData = fs.existsSync(bankPath) ? JSON.parse(fs.readFileSync(bankPath, 'utf8')) : {};

        if (interaction.customId === `reset_all_inv_${customId}`) {
          invData = {};
          fs.writeFileSync(invPath, JSON.stringify(invData, null, 2));
          await interaction.followUp({ content: 'All inventories have been reset globally.', ephemeral: true });
        } else if (interaction.customId === `reset_user_inv_${customId}`) {
          await interaction.followUp({ content: 'Please ping the user to reset their inventory.', ephemeral: true });
          const filter = m => m.author.id === message.author.id;
          const msgCollector = message.channel.createMessageCollector({ filter, max: 1 });

          msgCollector.on('collect', m => {
            const user = m.mentions.users.first();
            if (!user) return m.reply('Invalid input! Please ping a user.');
            if (!invData[user.id]) return m.reply('User not found in inventory data.');
            delete invData[user.id];
            fs.writeFileSync(invPath, JSON.stringify(invData, null, 2));
            m.reply(`Inventory for ${user.tag} has been reset.`);
          });
        } else if (interaction.customId === `reset_user_bank_${customId}`) {
          await interaction.followUp({ content: 'Please ping the user to reset their bank balance.', ephemeral: true });
          const filter = m => m.author.id === message.author.id;
          const msgCollector = message.channel.createMessageCollector({ filter, max: 1 });

          msgCollector.on('collect', m => {
            const user = m.mentions.users.first();
            if (!user) return m.reply('Invalid input! Please ping a user.');
            if (!bankData[user.id]) return m.reply('User not found in bank data.');
            delete bankData[user.id];
            fs.writeFileSync(bankPath, JSON.stringify(bankData, null, 2));
            m.reply(`Bank balance for ${user.tag} has been reset to 0.`);
          });
        } else if (interaction.customId === `reset_global_bank_${customId}`) {
          bankData = {};
          fs.writeFileSync(bankPath, JSON.stringify(bankData, null, 2));
          await interaction.followUp({ content: 'All bank balances have been reset globally.', ephemeral: true });
        }

        // Update panel to keep it active
        await panelMessage.edit({ embeds: [embed], components: [row1, row2] });
        return;
      }

      // Handle select menu interactions
      let balanceData = fs.existsSync(balancePath) ? JSON.parse(fs.readFileSync(balancePath, 'utf8')) : {};
      let invData = fs.existsSync(invPath) ? JSON.parse(fs.readFileSync(invPath, 'utf8')) : {};

      if (option === 'cancel') {
        await panelMessage.delete().catch(() => {});
        await interaction.followUp({ content: 'Admin panel closed.', ephemeral: true });
        collector.stop();
        return;
      }

      if (option === 'edit_balance') {
        await interaction.followUp({ content: 'Please ping the user and provide the new balance (e.g., `@User 5000`).', ephemeral: true });
        const filter = m => m.author.id === message.author.id;
        const msgCollector = message.channel.createMessageCollector({ filter, max: 1 });

        msgCollector.on('collect', m => {
          const user = m.mentions.users.first();
          const amount = parseInt(m.content.split(' ')[1]);
          if (!user || isNaN(amount)) return m.reply('Invalid input! Use `@User amount`.');
          balanceData[user.id] = amount;
          fs.writeFileSync(balancePath, JSON.stringify(balanceData, null, 2));
          m.reply(`Balance for ${user.tag} set to ${amount} Thunder Coins.`);
        });
      } else if (option === 'add_item') {
        await interaction.followUp({ content: 'Please provide the exact item name and quantity (e.g., `Kaiser Kiss 2`). Case-sensitive.', ephemeral: true });
        const filter = m => m.author.id === message.author.id;
        const msgCollector = message.channel.createMessageCollector({ filter, max: 1 });

        msgCollector.on('collect', m => {
          const args = m.content.match(/(.*)\s+(\d+)$/);
          if (!args) return m.reply('Invalid input! Use `item name quantity` (e.g., `Kaiser Kiss 2`).');
          const itemName = args[1].trim();
          const quantity = parseInt(args[2]);

          // Validate item name (exact, case-sensitive match)
          const validItem = shopItems.find(i => i.name === itemName);
          if (!validItem) {
            return m.reply(`Invalid item! Item name must match exactly (case-sensitive). Valid items: ${shopItems.map(i => `\`${i.name}\``).join(', ')}`);
          }

          if (!itemName || isNaN(quantity) || quantity <= 0) {
            return m.reply('Invalid input! Use `item name quantity` with a positive quantity.');
          }

          invData[message.author.id] = invData[message.author.id] || {};
          invData[message.author.id][itemName] = (invData[message.author.id][itemName] || 0) + quantity;
          fs.writeFileSync(invPath, JSON.stringify(invData, null, 2));
          m.reply(`Added ${quantity} ${itemName} to your inventory.`);
        });
      } else if (option === 'remove_balance') {
        await interaction.followUp({ content: 'Please ping the user to remove their balance.', ephemeral: true });
        const filter = m => m.author.id === message.author.id;
        const msgCollector = message.channel.createMessageCollector({ filter, max: 1 });

        msgCollector.on('collect', m => {
          const user = m.mentions.users.first();
          if (!user) return m.reply('Invalid input! Please ping a user.');
          if (!balanceData[user.id]) return m.reply('User not found in balance data.');
          delete balanceData[user.id];
          fs.writeFileSync(balancePath, JSON.stringify(balanceData, null, 2));
          m.reply(`Balance for ${user.tag} has been removed.`);
        });
      } else if (option === 'global_reset') {
        if (interaction.user.id !== '1029672039604289566') {
          return interaction.followUp({ content: 'Only the bot owner can use this option!', ephemeral: true });
        }
        balanceData = {};
        fs.writeFileSync(balancePath, JSON.stringify(balanceData, null, 2));
        await interaction.followUp({ content: 'All balances have been reset globally.', ephemeral: true });
      } else if (option === 'remove_item') {
        await interaction.followUp({ content: 'Please ping the user, provide the exact item name, and quantity (e.g., `@User Kaiser Kiss 1`). Case-sensitive.', ephemeral: true });
        const filter = m => m.author.id === message.author.id;
        const msgCollector = message.channel.createMessageCollector({ filter, max: 1 });

        msgCollector.on('collect', m => {
          const args = m.content.match(/<@!?(\d+)>\s*(.*?)\s*(\d+)/);
          if (!args) return m.reply('Invalid input! Use `@User item name quantity` (e.g., `@User Kaiser Kiss 1`).');
          const user = m.mentions.users.first();
          const itemName = args[2].trim();
          const quantity = parseInt(args[3]);

          // Validate item name (exact, case-sensitive match)
          const validItem = shopItems.find(i => i.name === itemName);
          if (!validItem) {
            return m.reply(`Invalid item! Item name must match exactly (case-sensitive). Valid items: ${shopItems.map(i => `\`${i.name}\``).join(', ')}`);
          }

          if (!user || !itemName || isNaN(quantity) || quantity <= 0) {
            return m.reply('Invalid input! Use `@User item name quantity` with a positive quantity.');
          }

          if (!invData[user.id] || !invData[user.id][itemName]) {
            return m.reply('Item not found in user\'s inventory.');
          }

          invData[user.id][itemName] -= quantity;
          if (invData[user.id][itemName] <= 0) delete invData[user.id][itemName];
          if (Object.keys(invData[user.id]).length === 0) delete invData[user.id];
          fs.writeFileSync(invPath, JSON.stringify(invData, null, 2));
          m.reply(`Removed ${quantity} ${itemName} from ${user.tag}'s inventory.`);
        });
      } else if (option === 'give_coins') {
        await interaction.followUp({ content: 'Please ping the user and provide the amount of Thunder Coins (e.g., `@User 1000`).', ephemeral: true });
        const filter = m => m.author.id === message.author.id;
        const msgCollector = message.channel.createMessageCollector({ filter, max: 1 });

        msgCollector.on('collect', m => {
          const user = m.mentions.users.first();
          const amount = parseInt(m.content.split(' ')[1]);
          if (!user || isNaN(amount) || amount <= 0) {
            return m.reply('Invalid input! Use `@User amount` with a positive amount.');
          }
          balanceData[user.id] = (balanceData[user.id] || 0) + amount;
          fs.writeFileSync(balancePath, JSON.stringify(balanceData, null, 2));
          m.reply(`Gave ${amount} Thunder Coins to ${user.tag}.`);
        });
      }

      // Update panel to keep it active
      await panelMessage.edit({ embeds: [embed], components: [row1, row2] });
    });

    // Handle timeout (1 minute of inactivity)
    collector.on('end', async (collected, reason) => {
      if (reason === 'time') {
        await panelMessage.delete().catch(() => {});
        await message.channel.send({ content: 'Admin panel closed due to 1 minute of inactivity.', ephemeral: true }).catch(() => {});
      }
    });

    // Handle case-insensitive "cancel" command
    const cancelCollector = message.channel.createMessageCollector({
      filter: m => m.author.id === message.author.id && m.content.toLowerCase() === 'cancel',
    });

    cancelCollector.on('collect', async () => {
      await panelMessage.delete().catch(() => {});
      await message.channel.send('Admin panel closed.');
      collector.stop();
      cancelCollector.stop();
    });
  },
};