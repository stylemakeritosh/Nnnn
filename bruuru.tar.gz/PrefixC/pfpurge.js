const { EmbedBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
  name: 'purge',
  description: 'Delete a specified number of messages in the channel (up to 1000).',
  usage: 'purge <amount>',
  async execute(message, args) {
    try {
      const amount = parseInt(args[0]);

      // Validate input
      if (isNaN(amount) || amount <= 0 || amount > 1000) {
        return message.reply('Please provide a number between 1 and 1000.');
      }

      // Check permissions
      if (!message.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
        return message.reply({
          embeds: [
            new EmbedBuilder()
              .setColor('#FF0000')
              .setDescription('❌ You need **Manage Messages** permission to use this command.')
          ]
        });
      }

      // Bulk delete messages
      await message.channel.bulkDelete(amount, true);

      // Send confirmation embed
      const embed = new EmbedBuilder()
        .setColor('#00FF00')
        .setTitle('🧹 Messages Purged')
        .setDescription(`Successfully deleted **${amount}** message${amount === 1 ? '' : 's'}!`)
        .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() })
        .setTimestamp();

      const reply = await message.channel.send({ embeds: [embed] });

      // Delete the embed after 5 seconds
      setTimeout(() => reply.delete().catch(console.error), 5000);
    } catch (error) {
      console.error('Purge prefix command error:', error);
      await message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor('#FF0000')
            .setDescription('❌ An error occurred while purging messages!')
        ]
      });
    }
  },
};