const { EmbedBuilder, PermissionsBitField } = require('discord.js');
const Staffs = require('../Staffs.js');

module.exports = {
  name: 'demote',
  async execute(message, args) {
    if (!message.member.permissions.has(PermissionsBitField.Flags.ManageRoles)) {
      return message.reply({
        embeds: [new EmbedBuilder()
          .setColor('#FF0000')
          .setDescription('❌ You do not have permission to manage roles!')]
      });
    }

    if (!message.guild.members.me.permissions.has(PermissionsBitField.Flags.ManageRoles)) {
      return message.reply({
        embeds: [new EmbedBuilder()
          .setColor('#FF0000')
          .setDescription('❌ I do not have permission to manage roles!')]
      });
    }

    const user = message.mentions.members.first();
    if (!user) {
      return message.reply({
        embeds: [new EmbedBuilder()
          .setColor('#FF0000')
          .setDescription('❌ Please mention a user to demote!')]
      });
    }

    if (user.id === message.author.id) {
      return message.reply({
        embeds: [new EmbedBuilder()
          .setColor('#FF0000')
          .setDescription('❌ You cannot demote yourself!')]
      });
    }

    const highestRole = message.member.roles.highest;
    const botHighestRole = message.guild.members.me.roles.highest;

    if (user.roles.highest.position >= highestRole.position) {
      return message.reply({
        embeds: [new EmbedBuilder()
          .setColor('#FF0000')
          .setDescription('❌ You cannot demote someone with a role equal to or higher than yours!')]
      });
    }

    let roleToRemove;
    const inputRole = args.slice(1).join(' ');

    if (inputRole) {
      const roleMention = message.mentions.roles.first();
      if (roleMention) {
        roleToRemove = roleMention;
      } else {
        const roleByName = message.guild.roles.cache.find(r =>
          r.name.toLowerCase() === inputRole.toLowerCase()
        );

        if (!roleByName) {
          const similar = message.guild.roles.cache.find(r =>
            r.name.toLowerCase().includes(inputRole.toLowerCase())
          );
          if (similar) roleToRemove = similar;
        } else {
          roleToRemove = roleByName;
        }
      }

      if (!roleToRemove) {
        return message.reply({
          embeds: [new EmbedBuilder()
            .setColor('#FF0000')
            .setDescription(`❌ Could not find any role similar to "${inputRole}"`)]
        });
      }

      if (!user.roles.cache.has(roleToRemove.id)) {
        return message.reply({
          embeds: [new EmbedBuilder()
            .setColor('#FF0000')
            .setDescription(`❌ ${user} does not have the role ${roleToRemove}`)]
        });
      }

    } else {
      const validRoles = message.guild.roles.cache
        .filter(r => user.roles.cache.has(r.id) && r.position < highestRole.position && r.position < botHighestRole.position)
        .sort((a, b) => b.position - a.position);

      roleToRemove = validRoles.first();
      if (!roleToRemove) {
        return message.reply({
          embeds: [new EmbedBuilder()
            .setColor('#FF0000')
            .setDescription(`❌ No valid role found to demote ${user}`)]
        });
      }
    }

    if (roleToRemove.position >= botHighestRole.position) {
      return message.reply({
        embeds: [new EmbedBuilder()
          .setColor('#FF0000')
          .setDescription(`❌ I cannot remove ${roleToRemove} because it is higher than my highest role!`)]
      });
    }

    try {
      await user.roles.remove(roleToRemove);

      const embed = new EmbedBuilder()
        .setColor('#FF0000')
        .setTitle('User Demoted')
        .setThumbnail(user.user.displayAvatarURL({ dynamic: true }))
        .addFields(
          { name: 'User', value: `${user} (${user.user.tag})`, inline: true },
          { name: 'Demoted By', value: `${message.member} (${message.author.tag})`, inline: true },
          { name: 'Demoted Role', value: `${roleToRemove}`, inline: true }
        )
        .setFooter({ text: `ID: ${user.id}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
        .setTimestamp();

      await message.reply({
        content: `${user}`,
        embeds: [embed]
      });

      const staffLogChannelId = Staffs.getStaffLogChannel(message.guild.id);
      if (staffLogChannelId) {
        const staffLogChannel = message.guild.channels.cache.get(staffLogChannelId);
        if (staffLogChannel) {
          await staffLogChannel.send({
            content: `${user}`,
            embeds: [embed]
          });
        }
      }

    } catch (error) {
      console.error('Error demoting user:', error);
      await message.reply({
        embeds: [new EmbedBuilder()
          .setColor('#FF0000')
          .setDescription('❌ An error occurred while demoting the user!')]
      });
    }
  },
};