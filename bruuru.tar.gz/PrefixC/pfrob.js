const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const balancePath = './Balance.json';
const invPath = './inventory.json';
const cdPath = './cdrob.json';
const emoji = '<:0_Deco_stargold:1363095379364679881>';

module.exports = {
  name: 'rob',
  description: 'Attempt to steal 25% of a user\'s Thunder Coins (10m cooldown)',
  execute(message, args) {
    try {
      if (!args[0] || !message.mentions.users.size) {
        return message.reply('Please mention a user to rob!');
      }
      const target = message.mentions.users.first();
      if (target.id === message.author.id) {
        return message.reply('You cannot rob yourself!');
      }

      let balanceData = JSON.parse(fs.readFileSync(balancePath, 'utf8'));
      let invData = fs.existsSync(invPath) ? JSON.parse(fs.readFileSync(invPath, 'utf8')) : {};
      let cdData = fs.existsSync(cdPath) ? JSON.parse(fs.readFileSync(cdPath, 'utf8')) : {};

      const userBalance = balanceData[message.author.id] ?? 0;
      const targetBalance = balanceData[target.id] ?? 0;
      if (userBalance === 0) {
        return message.reply('You have no Thunder Coins to risk!');
      }
      if (targetBalance === 0) {
        return message.reply(`${target.username} has no Thunder Coins to steal!`);
      }

      const now = Date.now();
      const exemptUserId = '1029672039604289566';
      if (message.author.id !== exemptUserId) {
        const cooldown = 10 * 60 * 1000; // 10 minutes
        const lastRob = cdData[message.author.id] || 0;
        if (now - lastRob < cooldown) {
          const timeLeft = cooldown - (now - lastRob);
          const minutes = Math.floor(timeLeft / 60000);
          const seconds = Math.floor((timeLeft % 60000) / 1000);
          return message.reply(`You're on cooldown! Try again in **${minutes}m ${seconds}s**.`);
        }
      }

      let robChance = 0.10; // Base 10% chance
      const userInv = invData[message.author.id] || {};
      const targetInv = invData[target.id] || {};
      const anriControlCount = userInv['Anri Control'] || 0;
      const hasGimmeM = userInv['Gimme... M'] || 0;
      const aikuDefenseCount = targetInv['Aiku Defense'] || 0;

      robChance += anriControlCount * 0.08; // +8% per Anri Control
      if (hasGimmeM > 0) robChance += 0.15; // +15% for Gimme... M (non-stacking)

      // Apply Aiku Defense: 25% reduction per item, max 50% (2 items)
      const aikuReduction = Math.min(aikuDefenseCount, 2) * 0.25;
      robChance = Math.max(0, robChance - aikuReduction); // Ensure robChance doesn't go below 0

      const stealAmount = Math.floor(targetBalance * 0.25); // 25% of target's balance
      const lossAmount = Math.floor(userBalance * 0.50); // 50% of user's balance

      const embed = new EmbedBuilder()
        .setColor('#FFD700')
        .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
        .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() });

      if (robChance <= 0) {
        // Automatic failure due to Aiku Defense
        embed
          .setTitle(`${emoji} Rob Blocked!`)
          .setDescription(`**${target.username}**'s **Aiku Defense** completely shut down your rob attempt!`)
          .addFields(
            { name: 'Your Balance', value: `${userBalance.toLocaleString()} Thunder Coins`, inline: true },
            { name: `${target.username}'s Balance`, value: `${targetBalance.toLocaleString()} Thunder Coins`, inline: true }
          );
      } else if (Math.random() < robChance) {
        balanceData[message.author.id] = userBalance + stealAmount;
        balanceData[target.id] = targetBalance - stealAmount;
        embed
          .setTitle(`${emoji} Rob Success!`)
          .setDescription(`You stole **${stealAmount.toLocaleString()} Thunder Coins** from ${target.username}!`)
          .addFields(
            { name: 'Your New Balance', value: `${balanceData[message.author.id].toLocaleString()} Thunder Coins`, inline: true },
            { name: `${target.username}'s New Balance`, value: `${balanceData[target.id].toLocaleString()} Thunder Coins`, inline: true }
          );
      } else {
        balanceData[message.author.id] = userBalance - lossAmount;
        embed
          .setTitle(`${emoji} Rob Failed!`)
          .setDescription(`You got caught and lost **${lossAmount.toLocaleString()} Thunder Coins**!`)
          .addFields(
            { name: 'Your New Balance', value: `${balanceData[message.author.id].toLocaleString()} Thunder Coins`, inline: true }
          );
      }

      if (message.author.id !== exemptUserId) {
        cdData[message.author.id] = now;
        fs.writeFileSync(cdPath, JSON.stringify(cdData, null, 2));
      }

      fs.writeFileSync(balancePath, JSON.stringify(balanceData, null, 2));

      message.channel.send({ embeds: [embed] });
    } catch (error) {
      console.error('Rob prefix command error:', error);
      message.reply('An error occurred!');
    }
  },
};