const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = './Balance.json';
const emoji = '<:0_Deco_stargold:1363095379364679881>';

module.exports = {
  name: 'gnumber',
  aliases: ['gn'],
  description: 'Bet Thunder Coins on a number (1-3). Win 2.1x if your number is picked!',
  usage: 'gnumber <number> <amount>',
  async execute(message, args) {
    try {
      if (args.length < 2) {
        return message.reply('⚠️ Usage: `gnumber <number> <amount>`');
      }

      const numberInput = parseInt(args[0]);
      const amount = parseInt(args[1]);

      // Validate number
      if (isNaN(numberInput) || numberInput < 1 || numberInput > 3) {
        return message.reply('🚫 Invalid number! Choose from: 1, 2, 3');
      }

      // Validate amount
      if (isNaN(amount) || amount <= 0) {
        return message.reply('🚫 Invalid amount!');
      }

      // Load balance data
      let balanceData = fs.existsSync(path) ? JSON.parse(fs.readFileSync(path, 'utf8')) : {};
      const userBalance = balanceData[message.author.id] ?? 0;

      if (amount > userBalance) {
        return message.reply('🚫 Insufficient Thunder Coins!');
      }

      // Animation sequence
      const animationMsg = await message.channel.send('🎰 Rolling the number...');
      await new Promise(resolve => setTimeout(resolve, 1000));
      await animationMsg.edit('🌟 Picking the result...');
      await new Promise(resolve => setTimeout(resolve, 1000));
      await animationMsg.edit('🎉 Revealing the number!');

      // Randomly select a number (1-3)
      const rolledNumber = Math.floor(Math.random() * 3) + 1;

      // Determine win condition
      const isWin = rolledNumber === numberInput;
      const reward = isWin ? Math.floor(amount * 2.1) : 0;

      // Update balance
      balanceData[message.author.id] = userBalance - amount + reward;
      fs.writeFileSync(path, JSON.stringify(balanceData, null, 2));

      // Create embed
      const embed = new EmbedBuilder()
        .setColor(isWin ? '#00FF00' : '#FF0000')
        .setTitle(`${emoji} Number Guess Outcome`)
        .setDescription(
          isWin
            ? `🎉 Number **${numberInput}** was a hit! You won **${reward.toLocaleString()}** Thunder Coins!`
            : `😔 Number **${numberInput}** missed. You lost **${amount.toLocaleString()}** Thunder Coins.`
        )
        .addFields(
          {
            name: 'Your Bet',
            value: `**Number**: ${numberInput}\n**Amount**: ${amount.toLocaleString()} ${emoji}`,
            inline: true
          },
          {
            name: 'Result',
            value: `**Rolled**: **${rolledNumber}**`,
            inline: true
          },
          {
            name: 'Balance',
            value: `${balanceData[message.author.id].toLocaleString()} ${emoji}`,
            inline: true
          }
        )
        .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
        .setFooter({ text: `Played in ${message.guild.name}`, iconURL: message.guild.iconURL() })
        .setTimestamp();

      await animationMsg.delete();
      message.channel.send({ embeds: [embed] });
    } catch (error) {
      console.error('Gnumber prefix command error:', error);
      message.reply('⚠️ An error occurred!');
    }
  },
};