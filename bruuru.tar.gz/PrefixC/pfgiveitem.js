const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const shopItems = require('../shopItems.js'); // Import shared shop items
const invPath = './inventory.json';
const emoji = '<:0_Deco_stargold:1363095379364679881>';

module.exports = {
  name: 'gitem',
  description: 'Give an item to another user',
  usage: 'gitem <@user> <item name> [quantity]',
  execute(message, args) {
    try {
      const targetUser = message.mentions.users.first();
      if (!targetUser) {
        return message.reply('Please mention a user! (e.g., `!gitem @user Item Name [quantity]`)');
      }

      // Extract quantity from the last argument if it's a number, otherwise default to 1
      const lastArg = args[args.length - 1];
      const quantity = !isNaN(lastArg) && parseInt(lastArg) > 0 ? parseInt(lastArg) : 1;
      const itemName = quantity > 1 ? args.slice(1, -1).join(' ').trim() : args.slice(1).join(' ').trim();

      if (!itemName) {
        return message.reply('Please specify an item!');
      }

      // Validate item name (case-insensitive)
      const validItem = shopItems.find(i => i.name.toLowerCase() === itemName.toLowerCase());
      if (!validItem) {
        return message.reply(`Invalid item! Choose from: ${shopItems.map(i => i.name).join(', ')}`);
      }

      const invData = fs.existsSync(invPath) ? JSON.parse(fs.readFileSync(invPath, 'utf8')) : {};
      const userInv = invData[message.author.id] || {};

      if (!userInv[validItem.name] || userInv[validItem.name] < quantity) {
        return message.reply(
          `You don’t have enough **${validItem.name}** in your inventory! You have **${userInv[validItem.name] || 0}**.`
        );
      }

      // Update giver's inventory
      userInv[validItem.name] -= quantity;
      if (userInv[validItem.name] === 0) delete userInv[validItem.name];
      invData[message.author.id] = userInv;

      // Update receiver's inventory
      invData[targetUser.id] = invData[targetUser.id] || {};
      invData[targetUser.id][validItem.name] = (invData[targetUser.id][validItem.name] || 0) + quantity;

      fs.writeFileSync(invPath, JSON.stringify(invData, null, 2));

      const embed = new EmbedBuilder()
        .setColor('#00CED1')
        .setTitle(`${emoji} Item Gifted!`)
        .setDescription(`${message.author} gave **${quantity} ${validItem.name}(s)** to ${targetUser}!`)
        .addFields(
          { name: 'Item', value: validItem.name, inline: true },
          { name: 'Quantity', value: quantity.toString(), inline: true },
          {
            name: 'Giver’s Inventory',
            value: `${userInv[validItem.name] || 0} ${validItem.name}(s) remaining`,
            inline: true,
          }
        )
        .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
        .setFooter({ text: `Shop • ${message.guild.name}`, iconURL: message.guild.iconURL() })
        .setTimestamp();

      message.channel.send({ embeds: [embed] });
    } catch (error) {
      console.error('Gitem prefix command error:', error);
      message.reply('An error occurred!');
    }
  },
};