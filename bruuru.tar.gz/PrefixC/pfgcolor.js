const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = './Balance.json';
const emoji = '<:0_Deco_stargold:1363095379364679881>';

const colors = ['red', 'blue', 'green', 'yellow', 'purple', 'orange', 'pink', 'black', 'white'];

module.exports = {
  name: 'gcolor',
  aliases: ['gc'],
  description: 'Bet Thunder Coins on a color. Win 2x if your color is among the 3 success colors!',
  usage: 'gcolor <color> <amount>',
  async execute(message, args) {
    try {
      if (args.length < 2) {
        return message.reply('⚠️ Usage: `gcolor <color> <amount>`');
      }

      const colorInput = args[0].toLowerCase();
      const amount = parseInt(args[1]);

      // Validate color
      if (!colors.includes(colorInput)) {
        return message.reply(`🚫 Invalid color! Choose from: ${colors.join(', ')}`);
      }

      // Validate amount
      if (isNaN(amount) || amount <= 0) {
        return message.reply('🚫 Invalid amount!');
      }

      // Load balance data
      let balanceData = fs.existsSync(path) ? JSON.parse(fs.readFileSync(path, 'utf8')) : {};
      const userBalance = balanceData[message.author.id] ?? 0;

      if (amount > userBalance) {
        return message.reply('🚫 Insufficient Thunder Coins!');
      }

      // Animation sequence
      const animationMsg = await message.channel.send('🎨 Shuffling colors...');
      await new Promise(resolve => setTimeout(resolve, 1000));
      await animationMsg.edit('🌟 Picking success colors...');
      await new Promise(resolve => setTimeout(resolve, 1000));
      await animationMsg.edit('🎉 Revealing results!');

      // Randomly select 9 colors (with replacement)
      const rolledColors = Array.from({ length: 9 }, () => colors[Math.floor(Math.random() * colors.length)]);
      // Randomly select 3 unique success colors
      const successColors = [];
      const rolledCopy = [...rolledColors];
      for (let i = 0; i < 3; i++) {
        const randomIndex = Math.floor(Math.random() * rolledCopy.length);
        successColors.push(rolledCopy.splice(randomIndex, 1)[0]);
      }

      // Determine win condition
      const isWin = successColors.includes(colorInput);
      const reward = isWin ? amount * 2 : 0;

      // Update balance
      balanceData[message.author.id] = userBalance - amount + reward;
      fs.writeFileSync(path, JSON.stringify(balanceData, null, 2));

      // Create embed
      const embed = new EmbedBuilder()
        .setColor(isWin ? '#00FF00' : '#FF0000')
        .setTitle(`${emoji} Color Guess Outcome`)
        .setDescription(
          isWin
            ? `🎉 **${colorInput}** was a hit! You won **${reward.toLocaleString()}** Thunder Coins!`
            : `😔 **${colorInput}** missed. You lost **${amount.toLocaleString()}** Thunder Coins.`
        )
        .addFields(
          {
            name: 'Your Bet',
            value: `**Color**: ${colorInput.charAt(0).toUpperCase() + colorInput.slice(1)}\n**Amount**: ${amount.toLocaleString()} ${emoji}`,
            inline: true
          },
          {
            name: 'Results',
            value: `**Rolled**: ${rolledColors.join(', ')}\n**Success**: **${successColors.join(', ')}**`,
            inline: true
          },
          {
            name: 'Balance',
            value: `${balanceData[message.author.id].toLocaleString()} ${emoji}`,
            inline: true
          }
        )
        .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
        .setFooter({ text: `Played in ${message.guild.name}`, iconURL: message.guild.iconURL() })
        .setTimestamp();

      await animationMsg.delete();
      message.channel.send({ embeds: [embed] });
    } catch (error) {
      console.error('Gcolor prefix command error:', error);
      message.reply('⚠️ An error occurred!');
    }
  },
};