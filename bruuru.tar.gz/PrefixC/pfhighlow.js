const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = './Balance.json';
const emoji = '<:0_Deco_stargold:1363095379364679881>';

module.exports = {
  name: 'highlow',
  aliases: ['hl'],
  description: 'Bet Thunder Coins for a 30% chance to triple your bet',
  usage: 'highlow <amount>',
  async execute(message, args) {
    try {
      const amount = parseInt(args[0]);

      if (isNaN(amount) || amount <= 0) {
        return message.reply('Please provide a valid amount!');
      }

      let balanceData = fs.existsSync(path) ? JSON.parse(fs.readFileSync(path, 'utf8')) : {};
      const userBalance = balanceData[message.author.id] ?? 0;

      if (amount > userBalance) {
        return message.reply('Insufficient Thunder Coins!');
      }

      // Animation sequence
      const animationMsg = await message.channel.send('Are You Lucky?... 🎲');
      await new Promise(resolve => setTimeout(resolve, 1000));
      await animationMsg.edit('Almost there... ⚡');
      await new Promise(resolve => setTimeout(resolve, 1000));
      await animationMsg.edit('Result!');

      const winChance = Math.random();
      const isWin = winChance <= 0.30; // 30% chance to win (increased from 25%)
      const reward = isWin ? amount * 3 : 0;

      balanceData[message.author.id] = userBalance - amount + reward;
      fs.writeFileSync(path, JSON.stringify(balanceData, null, 2));

      const embed = new EmbedBuilder()
        .setColor(isWin ? '#00FF00' : '#FF0000')
        .setTitle(`${emoji} High-Low Result`)
        .setDescription(
          isWin
            ? `Congratulations! You won **${reward.toLocaleString()} Thunder Coins** (3x your bet)!`
            : `Sorry, you lost **${amount.toLocaleString()} Thunder Coins**. Better luck next time!`
        )
        .addFields(
          { name: 'Bet Amount', value: `${amount.toLocaleString()} Thunder Coins`, inline: true },
          { name: 'New Balance', value: `${balanceData[message.author.id].toLocaleString()} Thunder Coins`, inline: true }
        )
        .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
        .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() });

      await animationMsg.delete(); // Delete animation message
      message.channel.send({ embeds: [embed] });
    } catch (error) {
      console.error('Highlow prefix command error:', error);
      message.reply('An error occurred!');
    }
  },
};