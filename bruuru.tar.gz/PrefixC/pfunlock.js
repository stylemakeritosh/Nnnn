const { EmbedBuilder, PermissionsBitField } = require('discord.js');
const emoji = '<:0_Deco_stargold:1363095379364679881>';

module.exports = {
  name: 'unlock',
  description: 'Unlock a channel to restore default message permissions.',
  usage: 'unlock [#channel]',
  async execute(message, args) {
    try {
      // Check permissions
      if (!message.member.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
        return message.reply('❌ You need **Manage Channels** permission to use this command!');
      }

      // Get channel
      const channel = args[0] ? message.mentions.channels.first() : message.channel;
      if (!channel || !channel.isTextBased()) {
        return message.reply('Please mention a valid text channel or use in a text channel!');
      }

      // Unlock channel by setting SEND_MESSAGES to null (neutral)
      await channel.permissionOverwrites.edit(message.guild.roles.everyone, {
        SendMessages: null,
      });

      // Create embed
      const embed = new EmbedBuilder()
        .setColor('#FFD700')
        .setTitle(`${emoji} Channel Unlocked`)
        .setDescription(`🔓 **${channel.name}** has been unlocked to default permissions!`)
        .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() })
        .setTimestamp();

      await message.channel.send({ embeds: [embed] });
    } catch (error) {
      console.error('Unlock prefix command error:', error);
      await message.reply('⚠️ An error occurred while unlocking the channel!');
    }
  },
};