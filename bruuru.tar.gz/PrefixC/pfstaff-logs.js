const { EmbedBuilder, PermissionsBitField } = require('discord.js');
const Staffs = require('../Staffs.js');

module.exports = {
  name: 'staff-log',
  async execute(message, args) {
    if (!message.member.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
      return message.reply({
        embeds: [new EmbedBuilder()
          .setColor('#FF0000')
          .setDescription('❌ You do not have permission to manage channels!')]
      });
    }

    const channel = message.mentions.channels.first();
    if (!channel) {
      return message.reply({
        embeds: [new EmbedBuilder()
          .setColor('#FF0000')
          .setDescription('❌ Please mention a channel to set as the staff log!')]
      });
    }

    try {
      Staffs.setStaffLogChannel(message.guild.id, channel.id);

      const embed = new EmbedBuilder()
        .setColor('#00FF00')
        .setTitle('Staff Log Channel Set')
        .addFields(
          { name: 'Channel', value: `${channel}`, inline: true },
          { name: 'Set By', value: `${message.member} (${message.author.tag})`, inline: true }
        )
        .setTimestamp();

      await message.reply({ embeds: [embed] });
    } catch (error) {
      console.error('Error setting staff log channel:', error);
      await message.reply({
        embeds: [new EmbedBuilder()
          .setColor('#FF0000')
          .setDescription('❌ An error occurred while setting the staff log channel!')]
      });
    }
  },
};