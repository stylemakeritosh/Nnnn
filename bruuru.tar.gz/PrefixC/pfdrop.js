const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = './Balance.json';

module.exports = {
  name: 'drop',
  description: 'Drop Thunder Coins for others to pick',
  execute(message, args) {
    try {
      const amount = parseInt(args[0]);
      if (isNaN(amount) || amount <= 0) return message.reply('Please specify a valid amount!');

      let channel = message.channel;
      if (args[1]?.startsWith('<#') && args[1].endsWith('>')) {
        const channelId = args[1].slice(2, -1);
        channel = message.guild.channels.cache.get(channelId);
        if (!channel) return message.reply('Invalid channel!');
      }

      const data = JSON.parse(fs.readFileSync(path, 'utf8'));
      if (!data[message.author.id] || data[message.author.id] < amount) {
        return message.reply('You don’t have enough Thunder Coins!');
      }

      const embed = new EmbedBuilder()
        .setColor('#FF4500')
        .setTitle('💰 Thunder Coin Drop!')
        .setDescription(`**${amount} Thunder Coins** dropped by ${message.author}!\nType **\`pick\`** to claim them!`)
        .setThumbnail(message.guild.iconURL({ dynamic: true }))
        .setFooter({ text: `Thunder Hub | ${message.guild.name}`, iconURL: message.client.user.displayAvatarURL() })
        .setTimestamp();

      channel.send({ embeds: [embed] });

      data[message.author.id] -= amount;
      fs.writeFileSync(path, JSON.stringify(data, null, 2));

      const filter = msg => msg.content.toLowerCase() === 'pick' && msg.author.id !== message.author.id;
      const collector = channel.createMessageCollector({ filter, time: 60000, max: 1 });

      collector.on('collect', msg => {
        data[msg.author.id] = (data[msg.author.id] || 0) + amount;
        fs.writeFileSync(path, JSON.stringify(data, null, 2));

        const successEmbed = new EmbedBuilder()
          .setColor('#00FF00')
          .setTitle('🎉 Coins Claimed!')
          .setDescription(`${msg.author} picked up **${amount} Thunder Coins**!`)
          .setThumbnail(message.guild.iconURL({ dynamic: true }))
          .setFooter({ text: `Thunder Hub | ${message.guild.name}`, iconURL: message.client.user.displayAvatarURL() })
          .setTimestamp();

        channel.send({ embeds: [successEmbed] });
      });

      collector.on('end', collected => {
        if (collected.size === 0) {
          const expiredEmbed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('⏰ Drop Expired!')
            .setDescription(`No one picked up the **${amount} Thunder Coins**. They’re gone!`)
            .setThumbnail(message.guild.iconURL({ dynamic: true }))
            .setFooter({ text: `Thunder Hub | ${message.guild.name}`, iconURL: message.client.user.displayAvatarURL() })
            .setTimestamp();

          channel.send({ embeds: [expiredEmbed] });
        }
      });
    } catch (error) {
      console.error('Drop error:', error);
      message.reply('An error occurred!');
    }
  },
};