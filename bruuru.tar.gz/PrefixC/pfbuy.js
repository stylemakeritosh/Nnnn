const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const shopItems = require('../shopItems.js'); // Import shared shop items
const path = './Balance.json';
const invPath = './inventory.json';
const emoji = '<:0_Deco_stargold:1363095379364679881>';

module.exports = {
  name: 'buy',
  description: 'Buy an item from the shop',
  usage: 'buy <item name> [quantity]',
  execute(message, args) {
    try {
      if (args.length === 0) {
        return message.reply('Please specify an item to buy!');
      }

      // Extract quantity from the last argument if it's a number, otherwise default to 1
      const lastArg = args[args.length - 1];
      const quantity = !isNaN(lastArg) && parseInt(lastArg) > 0 ? parseInt(lastArg) : 1;
      const itemName = quantity > 1 ? args.slice(0, -1).join(' ') : args.join(' ');

      const item = shopItems.find(i => i.name.toLowerCase() === itemName.toLowerCase());

      if (!item) {
        return message.reply('Invalid item name!');
      }

      const totalCost = item.price * quantity;
      let balanceData = fs.existsSync(path) ? JSON.parse(fs.readFileSync(path, 'utf8')) : {};
      let invData = fs.existsSync(invPath) ? JSON.parse(fs.readFileSync(invPath, 'utf8')) : {};

      const userBalance = balanceData[message.author.id] ?? 0;
      if (userBalance < totalCost) {
        return message.reply(
          `Insufficient Thunder Coins! You need **${totalCost.toLocaleString()}** coins for **${quantity} ${item.name}(s)**.`
        );
      }

      balanceData[message.author.id] = userBalance - totalCost;
      invData[message.author.id] = invData[message.author.id] || {};
      invData[message.author.id][item.name] = (invData[message.author.id][item.name] || 0) + quantity;

      fs.writeFileSync(path, JSON.stringify(balanceData, null, 2));
      fs.writeFileSync(invPath, JSON.stringify(invData, null, 2));

      const embed = new EmbedBuilder()
        .setColor('#FFD700')
        .setTitle(`${emoji} Purchase Successful`)
        .setDescription(`Successfully purchased **${quantity} ${item.name}(s)**!`)
        .addFields(
          { name: 'Item', value: item.name, inline: true },
          { name: 'Quantity', value: quantity.toString(), inline: true },
          { name: 'Unit Price', value: `${item.price.toLocaleString()} Thunder Coins`, inline: true },
          { name: 'Total Cost', value: `${totalCost.toLocaleString()} Thunder Coins`, inline: true },
          { name: 'New Balance', value: `${balanceData[message.author.id].toLocaleString()} Thunder Coins`, inline: true }
        )
        .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
        .setFooter({ text: `Shop • ${message.guild.name}`, iconURL: message.guild.iconURL() })
        .setTimestamp();

      message.channel.send({ embeds: [embed] });
    } catch (error) {
      console.error('Buy prefix command error:', error);
      message.reply('An error occurred!');
    }
  },
};