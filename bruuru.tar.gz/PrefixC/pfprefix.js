const fs = require('fs');
const { EmbedBuilder, PermissionsBitField } = require('discord.js');
const emoji = '<:0_Deco_stargold:1363095379364679881>';

module.exports = {
  name: 'setprefix',
  description: 'Change the bot prefix for this server (Admin only)',
  execute(message, args) {
    try {
      // Check for administrator permissions
      if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
        return message.reply('You need **Administrator** permissions to use this command!');
      }

      // Check if a new prefix was provided
      if (!args[0]) {
        return message.reply('Please provide a new prefix! Usage: `setprefix <new_prefix>`');
      }

      const newPrefix = args[0].trim();
      if (newPrefix.length > 5) {
        return message.reply('The prefix must be 5 characters or less!');
      }

      // Load or initialize Server.json
      let serverData = {};
      if (fs.existsSync('./Server.json')) {
        serverData = JSON.parse(fs.readFileSync('./Server.json', 'utf8'));
      }

      // Update the prefix for the guild
      serverData[message.guild.id] = newPrefix;
      fs.writeFileSync('./Server.json', JSON.stringify(serverData, null, 2));

      // Create success embed
      const embed = new EmbedBuilder()
        .setColor('#FFD700')
        .setTitle(`${emoji} Prefix Updated`)
        .setDescription(`The bot prefix for **${message.guild.name}** has been changed to \`${newPrefix}\`!`)
        .setThumbnail(message.guild.iconURL())
        .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() })
        .setTimestamp();

      message.channel.send({ embeds: [embed] });
    } catch (error) {
      console.error('Setprefix prefix command error:', error);
      message.reply('An error occurred while setting the prefix!');
    }
  },
};