const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const bankPath = './Bank.json';
const emoji = '<:0_Deco_stargold:1363095379364679881>';

module.exports = {
  name: 'banklb',
  description: 'Displays the top 10 users with the highest bank balances',
  usage: 'banklb',
  async execute(message) {
    try {
      // Read bank data
      const bankData = fs.existsSync(bankPath) ? JSON.parse(fs.readFileSync(bankPath, 'utf8')) : {};

      // Convert bank data to array, filter for server members, and sort by balance
      let leaderboard = Object.entries(bankData)
        .map(([userId, balance]) => ({ userId, balance }))
        .filter(entry => message.guild.members.cache.has(entry.userId))
        .sort((a, b) => b.balance - a.balance)
        .slice(0, 10); // Get top 10

      // Create embed
      const embed = new EmbedBuilder()
        .setColor('#FFD700')
        .setTitle(`${emoji} 🏆 Thunder Coin Bank Leaderboard`)
        .setDescription('Top 10 Server users with the highest bank balances!')
        .setThumbnail(message.guild.iconURL({ dynamic: true }) || 'https://cdn.discordapp.com/embed/avatars/0.png')
        .setFooter({
          text: `Server Leaderboard • ${message.guild.name}`,
          iconURL: message.guild.iconURL() || 'https://cdn.discordapp.com/embed/avatars/0.png'
        })
        .setTimestamp();

      // Build leaderboard
      let leaderboardText = '';
      if (leaderboard.length === 0) {
        leaderboardText = 'No users found on the leaderboard!';
      } else {
        leaderboardText = await Promise.all(
          leaderboard.map(async (entry, index) => {
            const user = await message.client.users.fetch(entry.userId).catch(() => null);
            const username = user ? user.username : 'Unknown User';
            const rankEmoji = index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : `**#${index + 1}**`;
            return `${rankEmoji} **${username}** - ${entry.balance.toLocaleString()} ${emoji}`;
          })
        ).then(lines => lines.join('\n'));
      }

      // Add leaderboard field
      embed.addFields({
        name: '🏅 Top Thunder Coin Holders',
        value: leaderboardText,
        inline: false
      });

      // Add total users field
      embed.addFields({
        name: '📊 Total Users',
        value: `${leaderboard.length} ranked users`,
        inline: true
      });

      // Send embed
      await message.channel.send({ embeds: [embed] });
    } catch (error) {
      console.error('Bank leaderboard prefix command error:', error);
      await message.reply('⚠️ An error occurred while generating the leaderboard!');
    }
  },
};