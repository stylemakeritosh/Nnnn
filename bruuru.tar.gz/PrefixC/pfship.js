const { EmbedBuilder } = require('discord.js');
const emoji = '<:0_Deco_stargold:1363095379364679881>';

module.exports = {
  name: 'ship',
  description: 'Calculate the compatibility between two users!',
  usage: 'ship @user [@user]',
  async execute(message, args) {
    try {
      // Get users
      const user1 = args.length === 2 ? message.mentions.users.first() : message.author;
      const user2 = args.length === 2 ? message.mentions.users.at(1) : args.length === 1 ? message.mentions.users.first() : null;

      // Validate input
      if (!user2 || user1.id === user2.id) {
        return message.reply('Please mention one or two different users to ship!');
      }

      // Generate random percentage
      const percentage = Math.floor(Math.random() * 100) + 1;

      // Determine flavor text based on percentage
      let flavorText = 'Go Make a Baby Already 🤤 💞';
      if (percentage > 80) flavorText = 'Maybe Your Meant To Be!🌹';
      else if (percentage > 50) flavorText = 'Trusted Eachother! 💖';
      else if (percentage > 20) flavorText = 'Might need some work! 💦';
      else flavorText = 'Better luck next time! 💔';

      // Create embed
      const embed = new EmbedBuilder()
        .setColor('#FFD700')
        .setTitle(`${emoji} Love Calculator`)
        .setDescription(flavorText)
        .addFields({
          name: '💑 Compatibility',
          value: `**${user1.username}** & **${user2.username}**: **${percentage}%**`,
          inline: false,
        })
        .setThumbnail(message.guild.iconURL({ dynamic: true }) || 'https://cdn.discordapp.com/embed/avatars/0.png')
        .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() })
        .setTimestamp();

      await message.channel.send({ embeds: [embed] });
    } catch (error) {
      console.error('Ship prefix command error:', error);
      await message.reply('⚠️ An error occurred while calculating compatibility!');
    }
  },
};