const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = './Balance.json';
const bankPath = './Bank.json';

module.exports = {
  name: 'daily',
  async execute(message) {
    const userId = message.author.id;

    // Read wallet and bank data
    const data = fs.existsSync(path) ? JSON.parse(fs.readFileSync(path, 'utf8')) : {};
    const bankData = fs.existsSync(bankPath) ? JSON.parse(fs.readFileSync(bankPath, 'utf8')) : {};
    const balance = data[userId] ?? 0;
    const bankBalance = bankData[userId] ?? 0;

    // Check if either balance is greater than 0
    if (balance > 0 || bankBalance > 0) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor('#FF0000')
            .setDescription('❌ You can only claim daily coins when both your **wallet** and **bank** have **0 Thunder Coins**. Hehe Thanks Rin')
        ]
      });
    }

    // Calculate earned coins
    let earned;
    if (Math.random() < 0.02) {
      // 2% chance for 10000-15000
      earned = Math.floor(Math.random() * 5001) + 10000;
    } else {
      // 98% chance for 1000-1600
      earned = Math.floor(Math.random() * 601) + 1000;
    }
    data[userId] = earned;
    fs.writeFileSync(path, JSON.stringify(data, null, 2));

    // Send success embed
    message.reply({
      embeds: [
        new EmbedBuilder()
          .setColor('#00FF00')
          .setDescription(`🎉 **Daily Claim!**\nYou received **${earned} Thunder Coins**!\n*Thanks Rin Hehe*`)
          .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
          .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() })
      ]
    });
  }
};