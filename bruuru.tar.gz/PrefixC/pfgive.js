const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = './Balance.json';
const emoji = '<:0_Deco_stargold:1363095379364679881>';

module.exports = {
  name: 'give',
  description: 'Give Thunder Coins to another user',
  usage: 'give <@user> <amount>',
  execute(message, args) {
    try {
      if (!message.mentions.users.size) {
        return message.reply('Please mention a user to give Thunder Coins to!');
      }

      const targetUser = message.mentions.users.first();
      const amount = parseInt(args[1]);

      if (isNaN(amount) || amount <= 0) {
        return message.reply('Please provide a valid amount!');
      }

      if (targetUser.bot) {
        return message.reply('You cannot give Thunder Coins to a bot!');
      }

      if (targetUser.id === message.author.id) {
        return message.reply('You cannot give Thunder Coins to yourself!');
      }

      let balanceData = fs.existsSync(path) ? JSON.parse(fs.readFileSync(path, 'utf8')) : {};
      const userBalance = balanceData[message.author.id] ?? 0;

      if (amount > userBalance) {
        return message.reply('Insufficient Thunder Coins!');
      }

      balanceData[message.author.id] = userBalance - amount;
      balanceData[targetUser.id] = (balanceData[targetUser.id] ?? 0) + amount;

      fs.writeFileSync(path, JSON.stringify(balanceData, null, 2));

      const embed = new EmbedBuilder()
        .setColor('#FFD700')
        .setTitle(`${emoji} Thunder Coins Gifted`)
        .setDescription(`You gave **${amount.toLocaleString()} Thunder Coins** to **${targetUser.username}**!`)
        .addFields(
          { name: 'Your New Balance', value: `${balanceData[message.author.id].toLocaleString()} Thunder Coins`, inline: true },
          { name: `${targetUser.username}'s New Balance`, value: `${balanceData[targetUser.id].toLocaleString()} Thunder Coins`, inline: true }
        )
        .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
        .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() });

      message.channel.send({ embeds: [embed] });
    } catch (error) {
      console.error('Give prefix command error:', error);
      message.reply('An error occurred!');
    }
  },
};