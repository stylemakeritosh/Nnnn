const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const invPath = './inventory.json';
const emoji = '<:0_Deco_stargold:1363095379364679881>';

module.exports = {
  name: 'inventory',
  description: 'View your or another user\'s inventory',
  aliases: ['inv'], // Optional: alternative command names
  execute(message, args) {
    try {
      // Determine the user (either mentioned user, user by ID, or the message author)
      let user = message.mentions.users.first();
      if (!user && args[0]) {
        // Try to fetch user by ID if no mention but an argument is provided
        user = message.client.users.cache.get(args[0]);
      }
      user = user || message.author; // Default to message author if no valid user is found

      // Read inventory data
      let invData = fs.existsSync(invPath) ? JSON.parse(fs.readFileSync(invPath, 'utf8')) : {};

      // Get user's inventory
      const userInv = invData[user.id] || {};
      let items = 'No items in inventory!';
      if (Object.keys(userInv).length > 0) {
        items = Object.entries(userInv)
          .map(([item, quantity]) => `**${item}** - ${quantity}`)
          .join('\n');
      }

      // Create the embed
      const embed = new EmbedBuilder()
        .setColor('#FFD700') // Gold color for consistency
        .setTitle(`${emoji} ${user.username}'s Inventory`)
        .setDescription(
          `**Inventory Contents**\n${items}\n\n` +
          `━━━━━━━━━━━━━━━━━━━━━\n` +
          `*Use -shop to acquire more items!*`
        )
        .setThumbnail(user.displayAvatarURL({ dynamic: true, size: 128 }))
        .setFooter({
          text: `${message.guild.name} | Inventory System`,
          iconURL: message.guild.iconURL({ dynamic: true }),
        })
        .setTimestamp();

      // Send the embed
      message.channel.send({ embeds: [embed] });
    } catch (error) {
      console.error('Inventory prefix command error:', error);
      message.reply({
        content: 'An error occurred while fetching the inventory!',
        ephemeral: true, // Note: ephemeral is not supported in prefix commands, so this will be a regular reply
      });
    }
  },
};