const { EmbedBuilder, PermissionsBitField } = require('discord.js');
const emoji = '<:0_Deco_stargold:1363095379364679881>';

module.exports = {
  name: 'rto',
  aliases: ['removetimeout'],
  description: 'Remove a user’s timeout.',
  usage: 'rto @user [reason]',
  async execute(message, args) {
    try {
      if (!message.guild.members.me.permissions.has(PermissionsBitField.Flags.ModerateMembers)) {
        return message.reply('⚠️ I lack permission to manage timeouts!');
      }
      if (!message.member.permissions.has(PermissionsBitField.Flags.ModerateMembers)) {
        return message.reply('⚠️ You lack permission to manage timeouts!');
      }

      const target = message.mentions.members.first();
      if (!target) return message.reply('Please mention a user!');

      const userHighestRole = message.member.roles.highest;
      const targetHighestRole = target.roles.highest;
      if (userHighestRole.position <= targetHighestRole.position) {
        return message.reply('You cannot remove timeouts from users with equal or higher roles!');
      }

      if (!target.moderatable) {
        return message.reply('I cannot manage this user’s timeout! They may be the server owner or have higher permissions.');
      }

      if (!target.isCommunicationDisabled()) {
        return message.reply('This user is not timed out!');
      }

      const reason = args.slice(1).join(' ') || 'No reason provided';
      await target.timeout(null, `Timeout removed by ${message.author.tag}: ${reason}`);

      const embed = new EmbedBuilder()
        .setColor('#55FF55')
        .setTitle(`${emoji} Timeout Removed`)
        .addFields(
          { name: 'User', value: `<@${target.id}>`, inline: true },
          { name: 'Reason', value: reason, inline: true }
        )
        .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() || 'https://cdn.discordapp.com/embed/avatars/0.png' })
        .setTimestamp();

      await message.channel.send({ content: `Timeout removed for <@${target.id}>!`, embeds: [embed] });
    } catch (error) {
      console.error('Remove timeout prefix command error:', error);
      await message.reply('⚠️ Error removing timeout!');
    }
  },
};