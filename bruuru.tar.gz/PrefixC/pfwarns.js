const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const warnsPath = './warns.json';
const emoji = '<:0_Deco_stargold:1363095379364679881>';

module.exports = {
  name: 'warns',
  description: 'View warnings for a user',
  usage: 'warns [@user]',
  permissions: ['ModerateMembers'],
  async execute(message, args) {
    try {
      // Check permissions
      if (!message.member.permissions.has('ModerateMembers')) {
        return message.reply('⚠️ You need the `Moderate Members` permission to use this command!');
      }
      if (!message.guild.members.me.permissions.has('ModerateMembers')) {
        return message.reply('⚠️ I need the `Moderate Members` permission to view warnings!');
      }

      // Get user (default to author)
      const user = message.mentions.users.first() || message.author;

      // Read warns data
      const warnsData = fs.existsSync(warnsPath) ? JSON.parse(fs.readFileSync(warnsPath, 'utf8')) : {};
      const guildWarns = warnsData[message.guild.id] || {};
      const userWarns = guildWarns[user.id] || [];

      // Create embed
      const embed = new EmbedBuilder()
        .setColor('#FFD700')
        .setTitle(`${emoji} Warnings for ${user.tag}`)
        .setThumbnail(message.guild.iconURL({ dynamic: true }) || 'https://cdn.discordapp.com/embed/avatars/0.png')
        .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() })
        .setTimestamp();

      // Build warnings list
      let warningsText = userWarns.length
        ? await Promise.all(
            userWarns.map(async warn => {
              const mod = await message.client.users.fetch(warn.moderatorId).catch(() => null);
              return `**Warning ${warn.id}**\nReason: ${warn.reason}\nDate: <t:${Math.floor(warn.date / 1000)}:R>\nModerator: ${mod ? mod.tag : 'Unknown'}`;
            })
          ).then(lines => lines.join('\n\n'))
        : 'No warnings found!';

      embed.addFields({ name: `Total Warnings: ${userWarns.length}`, value: warningsText, inline: false });

      await message.channel.send({ embeds: [embed] });
    } catch (error) {
      console.error('Warns prefix command error:', error);
      await message.reply('⚠️ An error occurred while fetching warnings!');
    }
  },
};