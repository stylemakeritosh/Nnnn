module.exports = {
  name: 'pick',
  description: 'Pick up dropped Thunder Coins',
  execute(message) {
    // Logic handled in drop.js collector
    message.channel.send('Type `pick` to claim the coins!');
  },
};