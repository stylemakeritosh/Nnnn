const { EmbedBuilder, PermissionsBitField } = require('discord.js');
const Staffs = require('../Staffs.js');

module.exports = {
  name: 'promote',
  async execute(message, args) {
    // Check if the command user has Manage Roles permission
    if (!message.member.permissions.has(PermissionsBitField.Flags.ManageRoles)) {
      return message.reply({
        embeds: [new EmbedBuilder()
          .setColor('#FF0000')
          .setDescription('❌ You do not have permission to manage roles!')]
      });
    }

    // Check if the bot has Manage Roles permission
    if (!message.guild.members.me.permissions.has(PermissionsBitField.Flags.ManageRoles)) {
      return message.reply({
        embeds: [new EmbedBuilder()
          .setColor('#FF0000')
          .setDescription('❌ I do not have permission to manage roles!')]
      });
    }

    // Get the mentioned user
    const user = message.mentions.members.first();
    if (!user) {
      return message.reply({
        embeds: [new EmbedBuilder()
          .setColor('#FF0000')
          .setDescription('❌ Please mention a user to promote!')]
      });
    }

    // Prevent self-promotion
    if (user.id === message.author.id) {
      return message.reply({
        embeds: [new EmbedBuilder()
          .setColor('#FF0000')
          .setDescription('❌ You cannot promote yourself!')]
      });
    }

    const highestRole = message.member.roles.highest;
    const botHighestRole = message.guild.members.me.roles.highest;

    // Get the role to add
    let roleToAdd;
    const inputRole = args.slice(1).join(' ').trim();

    if (inputRole) {
      // Check for role mention
      const roleMention = message.mentions.roles.first();
      if (roleMention) {
        roleToAdd = roleMention;
      } else {
        // Search for role by name or partial match
        const roles = message.guild.roles.cache
          .filter(r => r.position < highestRole.position && r.position < botHighestRole.position && !r.managed)
          .map(r => ({ name: r.name, id: r.id, role: r }));

        // Try exact match first
        roleToAdd = roles.find(r => r.name.toLowerCase() === inputRole.toLowerCase())?.role;

        // If no exact match, try partial match
        if (!roleToAdd) {
          roleToAdd = roles.find(r => r.name.toLowerCase().includes(inputRole.toLowerCase()))?.role;
        }

        // If no match found, suggest a similar role
        if (!roleToAdd) {
          const similarRole = roles.find(r => r.name.toLowerCase().startsWith(inputRole.toLowerCase()[0]));
          if (similarRole) {
            return message.reply({
              embeds: [new EmbedBuilder()
                .setColor('#FF0000')
                .setDescription(`❌ Could not find role "${inputRole}". Did you mean **${similarRole.name}**?`)]
            });
          } else {
            return message.reply({
              embeds: [new EmbedBuilder()
                .setColor('#FF0000')
                .setDescription(`❌ Could not find any role similar to "${inputRole}"`)]
            });
          }
        }
      }

      // Validate the role
      if (roleToAdd.position >= highestRole.position) {
        return message.reply({
          embeds: [new EmbedBuilder()
            .setColor('#FF0000')
            .setDescription(`❌ You cannot assign ${roleToAdd} because it is equal to or higher than your highest role!`)]
        });
      }

      if (roleToAdd.position >= botHighestRole.position) {
        return message.reply({
          embeds: [new EmbedBuilder()
            .setColor('#FF0000')
            .setDescription(`❌ I cannot assign ${roleToAdd} because it is equal to or higher than my highest role!`)]
        });
      }

      if (user.roles.cache.has(roleToAdd.id)) {
        return message.reply({
          embeds: [new EmbedBuilder()
            .setColor('#FF0000')
            .setDescription(`❌ ${user} already has the role ${roleToAdd}`)]
        });
      }
    } else {
      // Find the next role above the user's current highest role
      const validRoles = message.guild.roles.cache
        .filter(r => r.position < highestRole.position && r.position < botHighestRole.position && !r.managed)
        .sort((a, b) => a.position - b.position);

      roleToAdd = validRoles.find(r => r.position > user.roles.highest.position);
      if (!roleToAdd) {
        return message.reply({
          embeds: [new EmbedBuilder()
            .setColor('#FF0000')
            .setDescription(`❌ No valid role found to promote ${user}`)]
        });
      }
    }

    try {
      // Add the role to the user
      await user.roles.add(roleToAdd);

      // Create success embed
      const embed = new EmbedBuilder()
        .setColor('#00FF00')
        .setTitle('User Promoted')
        .setThumbnail(user.user.displayAvatarURL({ dynamic: true }))
        .addFields(
          { name: 'User', value: `${user} (${user.user.tag})`, inline: true },
          { name: 'Promoted By', value: `${message.member} (${message.author.tag})`, inline: true },
          { name: 'Promoted Role', value: `${roleToAdd}`, inline: true }
        )
        .setFooter({ text: `ID: ${user.id}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
        .setTimestamp();

      // Reply to the command
      await message.reply({
        content: `${user}`,
        embeds: [embed]
      });

      // Log to staff channel if configured
      const staffLogChannelId = Staffs.getStaffLogChannel(message.guild.id);
      if (staffLogChannelId) {
        const staffLogChannel = message.guild.channels.cache.get(staffLogChannelId);
        if (staffLogChannel) {
          await staffLogChannel.send({
            content: `${user}`,
            embeds: [embed]
          });
        }
      }
    } catch (error) {
      console.error('Error promoting user:', error);
      let errorMessage = '❌ An error occurred while promoting the user!';
      if (error.code === 50013) {
        errorMessage = '❌ I lack the permissions to assign this role. Please ensure my role is above the target role and I have Manage Roles permission!';
      }
      await message.reply({
        embeds: [new EmbedBuilder()
          .setColor('#FF0000')
          .setDescription(errorMessage)]
      });
    }
  },
};