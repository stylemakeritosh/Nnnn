const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = './Balance.json';
const emoji = '<:0_Deco_stargold:1363095379364679881>';

module.exports = {
  name: 'coinflip',
  description: 'Bet Thunder Coins on a coin flip with a 50% chance to double your bet!',
  usage: 'coinflip <amount> <heads/tails>',
  async execute(message, args) {
    try {
      const userId = message.author.id;
      const amount = parseInt(args[0]);
      const guess = args[1]?.toLowerCase();

      if (isNaN(amount) || amount <= 0 || !['heads', 'tails'].includes(guess)) {
        return message.reply('Usage: `coinflip <amount> <heads/tails>`');
      }

      let data = fs.existsSync(path) ? JSON.parse(fs.readFileSync(path, 'utf8')) : {};
      const balance = data[userId] ?? 0;

      if (amount > balance) {
        return message.reply({
          embeds: [
            new EmbedBuilder()
              .setColor('#FF0000')
              .setDescription('❌ Insufficient Thunder Coins! Use `daily` to get more.')
          ]
        });
      }

      // Animation sequence
      const animationMsg = await message.channel.send('Flipping The Coin <a:coinspin:1363362113950843050>');
      await new Promise(resolve => setTimeout(resolve, 1000));
      await animationMsg.edit("Let's see...");
      await new Promise(resolve => setTimeout(resolve, 1000));
      await animationMsg.edit('You Got...');

      const flip = Math.random() < 0.5 ? 'heads' : 'tails';
      const isWin = guess === flip;
      const reward = isWin ? amount : -amount;
      const newBalance = balance + reward;

      data[userId] = newBalance;
      fs.writeFileSync(path, JSON.stringify(data, null, 2));

      const embed = new EmbedBuilder()
        .setColor(isWin ? '#00FF00' : '#FF0000')
        .setTitle(`${emoji} Coin Flip`)
        .setDescription(isWin ? `🎉 **${flip}**! You doubled your bet!` : `😔 **${flip}**. Better luck next time!`)
        .addFields(
          { name: 'Guess', value: guess.charAt(0).toUpperCase() + guess.slice(1), inline: true },
          { name: 'Bet', value: `${amount.toLocaleString()} TC`, inline: true },
          { name: 'Payout', value: `${reward > 0 ? '+' : ''}${reward.toLocaleString()} TC`, inline: true },
          { name: 'Balance', value: `${newBalance.toLocaleString()} TC`, inline: true }
        )
        .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
        .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() });

      await animationMsg.delete();
      await message.channel.send({ embeds: [embed] });
    } catch (error) {
      console.error('Coinflip prefix command error:', error);
      await message.reply('An error occurred!');
    }
  },
};