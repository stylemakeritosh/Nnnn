const { EmbedBuilder } = require('discord.js');
const shopItems = require('../shopItems.js'); // Import shared shop items
const emoji = '<:0_Deco_stargold:1363095379364679881>';

module.exports = {
  name: 'shop',
  description: 'View the Thunder Coin shop',
  execute(message) {
    try {
      const embed = new EmbedBuilder()
        .setColor('#FFD700')
        .setTitle(`${emoji} Thunder Coin Shop`)
        .setDescription('Browse the available items below!')
        .setThumbnail(message.guild.iconURL())
        .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() });

      const fields = shopItems.map(item => ({
        name: item.name,
        value: `Price: **${item.price.toLocaleString()} Thunder Coins**\n${item.description || 'No description available.'}`,
        inline: true,
      }));

      embed.addFields(fields);
      message.channel.send({ embeds: [embed] });
    } catch (error) {
      console.error('Shop prefix command error:', error);
      message.reply('An error occurred!');
    }
  },
};