const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = './Balance.json';
const emoji = '<:0_Deco_stargold:1363095379364679881>';

module.exports = {
  name: 'balance',
  aliases: ['bal'],
  async execute(message, args) {
    const user = message.mentions.users.first() || message.author;
    const data = JSON.parse(fs.readFileSync(path, 'utf8'));
    const coins = data[user.id] ?? 0;

    const embed = new EmbedBuilder()
      .setColor('#FFD700')
      .setTitle(`${emoji} Balance`)
      .setDescription(`You currently have **${coins} Thunder Coins**!`)
      .setThumbnail(user.displayAvatarURL({ dynamic: true }))
      .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() });

    message.reply({ embeds: [embed] });
  }
};