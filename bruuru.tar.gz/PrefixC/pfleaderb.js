const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const balancePath = './Balance.json';
const prizePath = './prize.json';
const emoji = '<:0_Deco_stargold:1363095379364679881>';

module.exports = {
  name: 'lb',
  description: 'Display the top 10 Thunder Coin holders!',
  usage: 'lb [global]',

  async execute(message, args) {
    try {
      // Read balance and prize data
      const balanceData = fs.existsSync(balancePath) ? JSON.parse(fs.readFileSync(balancePath, 'utf8')) : {};
      const prizeData = fs.existsSync(prizePath) ? JSON.parse(fs.readFileSync(prizePath, 'utf8')) : {};
      const guildPrizeData = prizeData[message.guild.id] || {};

      // Determine scope
      const isGlobal = args[0] && args[0].toLowerCase() === 'global';
      const scopeText = isGlobal ? 'Global' : 'Server';

      // Convert balance data to array and sort by coins
      let leaderboard = Object.entries(balanceData)
        .map(([userId, coins]) => ({ userId, coins }))
        .sort((a, b) => b.coins - a.coins);

      // Filter for server members if not global
      if (!isGlobal) {
        leaderboard = leaderboard.filter(entry => message.guild.members.cache.has(entry.userId));
      }

      // Get top 10
      leaderboard = leaderboard.slice(0, 10);

      // Create embed
      const embed = new EmbedBuilder()
        .setColor('#FFD700')
        .setTitle(`${emoji} 🏆 Thunder Coin Leaderboard`)
        .setDescription(`Top 10 ${scopeText} users with the most Thunder Coins!`)
        .setThumbnail(message.guild.iconURL({ dynamic: true }) || 'https://cdn.discordapp.com/embed/avatars/0.png')
        .setFooter({ 
          text: `${scopeText} Leaderboard • ${message.guild.name}`, 
          iconURL: message.guild.iconURL() || 'https://cdn.discordapp.com/embed/avatars/0.png' 
        })
        .setTimestamp();

      // Build leaderboard
      let leaderboardText = '';
      if (leaderboard.length === 0) {
        leaderboardText = 'No users found on the leaderboard!';
      } else {
        leaderboardText = await Promise.all(
          leaderboard.map(async (entry, index) => {
            const user = await message.client.users.fetch(entry.userId).catch(() => null);
            const username = user ? user.username : 'Unknown User';
            const rankEmoji = index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : `**#${index + 1}**`;
            return `${rankEmoji} **${username}** - ${entry.coins.toLocaleString()} ${emoji}`;
          })
        ).then(lines => lines.join('\n'));
      }

      // Add leaderboard field
      embed.addFields({
        name: '🏅 Top Thunder Coin Holders',
        value: leaderboardText,
        inline: false
      });

      // Add prize information
      if (guildPrizeData.roleId && guildPrizeData.nextAwardTime) {
        const timeLeft = guildPrizeData.nextAwardTime - Date.now();
        if (timeLeft > 0) {
          const hours = Math.floor(timeLeft / (1000 * 60 * 60));
          const minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
          const seconds = Math.floor((timeLeft % (1000 * 60)) / 1000);
          embed.addFields({
            name: '🎉 Prize for #1',
            value: `**Role**: <@&${guildPrizeData.roleId}>\n**Next Award**: <t:${Math.floor(guildPrizeData.nextAwardTime / 1000)}:R> (${hours}h ${minutes}m ${seconds}s)`,
            inline: true
          });
        }
      } else {
        embed.addFields({
          name: '🎁 Prize Info',
          value: 'No prize set! Use `/setlbprize` to configure one.',
          inline: true
        });
      }

      // Add total users field
      embed.addFields({
        name: '📊 Total Users',
        value: `${leaderboard.length} ranked users`,
        inline: true
      });

      await message.channel.send({ embeds: [embed] });
    } catch (error) {
      console.error('Leaderboard prefix command error:', error);
      await message.reply('⚠️ An error occurred while generating the leaderboard!');
    }
  },
};