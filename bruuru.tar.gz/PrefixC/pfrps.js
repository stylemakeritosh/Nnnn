const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = './Balance.json';
const emoji = '<:0_Deco_stargold:1363095379364679881>';

module.exports = {
  name: 'rps',
  description: 'Bet Thunder Coins on Rock, Paper, Scissors with a 2.2x payout on win!',
  usage: 'rps <rock/paper/scissors> <amount>',
  async execute(message, args) {
    try {
      const userId = message.author.id;
      const choice = args[0]?.toLowerCase();
      const amount = parseInt(args[1]);

      // Validate input
      if (!['rock', 'paper', 'scissors'].includes(choice) || isNaN(amount) || amount <= 0) {
        return message.reply('Usage: `rps <rock/paper/scissors> <amount>`');
      }

      // Load balance
      let data = fs.existsSync(path) ? JSON.parse(fs.readFileSync(path, 'utf8')) : {};
      const balance = data[userId] ?? 0;

      if (amount > balance) {
        return message.reply({
          embeds: [
            new EmbedBuilder()
              .setColor('#FF0000')
              .setDescription('❌ Insufficient Thunder Coins! Try `/daily` for more.')
          ]
        });
      }

      // Animation sequence
      const animationMsg = await message.channel.send('Playing Rock, Paper, Scissors... ✊✋✌');
      await new Promise(resolve => setTimeout(resolve, 1000));
      await animationMsg.edit('Choosing...');
      await new Promise(resolve => setTimeout(resolve, 1000));
      await animationMsg.edit('Result...');

      // Bot's choice and outcome
      const choices = ['rock', 'paper', 'scissors'];
      const botChoice = choices[Math.floor(Math.random() * 3)];
      let result = 'lose';
      let reward = -amount;

      if (choice === botChoice) {
        result = 'tie';
        reward = 0;
      } else if (
        (choice === 'rock' && botChoice === 'scissors') ||
        (choice === 'paper' && botChoice === 'rock') ||
        (choice === 'scissors' && botChoice === 'paper')
      ) {
        result = 'win';
        reward = Math.floor(amount * 1.2); // 2.2x total = bet + 1.2x bet
      }

      const newBalance = balance + reward;
      data[userId] = newBalance;
      fs.writeFileSync(path, JSON.stringify(data, null, 2));

      // Create embed
      const embed = new EmbedBuilder()
        .setColor(result === 'win' ? '#00FF00' : result === 'tie' ? '#FFFF00' : '#FF0000')
        .setTitle(`${emoji} Rock, Paper, Scissors`)
        .setDescription(
          result === 'win' ? `🎉 **${choice.toUpperCase()}** beats **${botChoice}**!` :
          result === 'tie' ? `🤝 It's a tie! Both chose **${choice}**.` :
          `😔 **${botChoice.toUpperCase()}** beats **${choice}**.`
        )
        .addFields(
          { name: '🎯 Your Choice', value: choice.charAt(0).toUpperCase() + choice.slice(1), inline: true },
          { name: '🤖 Bot Choice', value: botChoice.charAt(0).toUpperCase() + botChoice.slice(1), inline: true },
          { name: '💸 Bet', value: `${amount.toLocaleString()}`, inline: true },
          { name: '🏆 Payout', value: `${reward >= 0 ? '+' : ''}${reward.toLocaleString()}`, inline: true },
          { name: '💰 Balance', value: `${newBalance.toLocaleString()}`, inline: true }
        )
        .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
        .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() })
        .setTimestamp();

      await animationMsg.delete();
      await message.channel.send({ embeds: [embed] });
    } catch (error) {
      console.error('RPS prefix command error:', error);
      await message.reply('An error occurred!');
    }
  },
};