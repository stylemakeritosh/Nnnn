const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'fbtest',
  description: 'Test how much of a femboy you or someone else is!',
  usage: '[@user]',
  async execute(message, args) {
    try {
      // Determine user (mentioned or author)
      let user = message.mentions.users.first() || message.author;
      if (args.length > 0 && !user) {
        try {
          user = await message.client.users.fetch(args[0].replace(/[<@!>]/g, '')).catch(() => null);
          if (!user) return message.reply('Babe, that user’s nowhere to be found.');
        } catch {
          return message.reply('Invalid user, cutie. Try again?');
        }
      }

      // Generate random percentage (1–101)
      const percent = Math.floor(Math.random() * 101) + 1;

      // Define flirty Gen Z descriptions for every 10% range
      const vibes = {
        10: 'Just a hint of femboy charm, but you’re catching my eye already.',
        20: 'Soft boi vibes sneaking in, wanna borrow my skirt?',
        30: 'You’re teasing femboy energy, and I’m kinda into it.',
        40: 'Halfway to stealing hearts with that femboy glow, keep it up.',
        50: 'Perfect mix of masc and fab, you’re making me blush.',
        60: 'Serving femboy realness, babe, you’ve got my attention.',
        70: 'High-key femboy vibes, and I’m falling for it hard.',
        80: 'Femboy royalty, you’re out here breaking hearts.',
        90: 'Iconic femboy energy, I can’t stop staring, gorgeous.',
        100: 'Ultimate femboy perfection, you’ve got me weak.',
        101: 'Femboy beyond this world, I’m totally enchanted.'
      };

      // Get description based on nearest 10% (or 101)
      const vibeKey = percent === 101 ? 101 : Math.round(percent / 10) * 10;
      const vibe = vibes[vibeKey] || 'Femboy mystery, and I’m dying to know more.';

      // Create embed
      const embed = new EmbedBuilder()
        .setColor('#FF69B4') // Hot pink for flirty aesthetic
        .setTitle('🌸 Femboy Test Results')
        .setDescription(`**${user.username} is ${percent}% femboy!**\n${vibe}`)
        .setThumbnail(user.displayAvatarURL({ dynamic: true, size: 128 }))
        .setFooter({ text: 'Keep slaying, darling.' })
        .setTimestamp();

      // Send embed
      await message.channel.send({ embeds: [embed] });
    } catch (error) {
      console.error('Femboy test prefix command error:', error);
      await message.reply('Oh no, something broke, babe. Try again?');
    }
  },
};