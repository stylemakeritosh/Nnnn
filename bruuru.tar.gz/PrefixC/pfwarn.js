const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const warnsPath = './warns.json';
const emoji = '<:0_Deco_stargold:1363095379364679881>';

module.exports = {
  name: 'warn',
  description: 'Warn a user with a reason',
  usage: 'warn [@user] [reason]',
  permissions: ['ModerateMembers'],
  async execute(message, args) {
    try {
      // Check permissions
      if (!message.member.permissions.has('ModerateMembers')) {
        return message.reply('⚠️ You need the `Moderate Members` permission to use this command!');
      }
      if (!message.guild.members.me.permissions.has('ModerateMembers')) {
        return message.reply('⚠️ I need the `Moderate Members` permission to warn users!');
      }

      // Check if no arguments provided
      if (!args.length) {
        return message.reply(`⚠️ Usage: \`${this.usage}\``);
      }

      // Get user
      const user = message.mentions.users.first();
      if (!user) {
        return message.reply('⚠️ Please mention a valid user to warn!');
      }
      if (user.bot) {
        return message.reply('⚠️ You cannot warn bots!');
      }

      // Get reason (default to "No reason provided")
      const reason = args.slice(1).join(' ') || 'No reason provided';

      // Read warns data
      let warnsData = {};
      try {
        if (fs.existsSync(warnsPath)) {
          warnsData = JSON.parse(fs.readFileSync(warnsPath, 'utf8'));
        }
      } catch (error) {
        console.error('Error reading warns.json:', error);
        return message.reply('⚠️ Failed to read warnings data!');
      }

      const guildWarns = warnsData[message.guild.id] || {};
      const userWarns = guildWarns[user.id] || [];

      // Add new warning
      const warnId = userWarns.length + 1;
      userWarns.push({
        id: warnId,
        reason,
        date: Date.now(),
        moderatorId: message.author.id,
      });

      // Update warns data
      guildWarns[user.id] = userWarns;
      warnsData[message.guild.id] = guildWarns;
      try {
        fs.writeFileSync(warnsPath, JSON.stringify(warnsData, null, 2));
      } catch (error) {
        console.error('Error writing to warns.json:', error);
        return message.reply('⚠️ Failed to save warnings data!');
      }

      // Create embed
      const embed = new EmbedBuilder()
        .setColor('#FFD700')
        .setTitle(`${emoji} User Warned`)
        .setDescription(`**${user.tag}** has been warned!`)
        .addFields(
          { name: 'Warning', value: `This is your **${warnId}${warnId === 1 ? 'st' : warnId === 2 ? 'nd' : warnId === 3 ? 'rd' : 'th'}** warning!`, inline: true },
          { name: 'Reason', value: reason, inline: true }
        )
        .setThumbnail(message.guild.iconURL({ dynamic: true }) || 'https://cdn.discordapp.com/embed/avatars/0.png')
        .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() })
        .setTimestamp();

      // Send message with user mention outside embed
      await message.channel.send({ content: `<@${user.id}>`, embeds: [embed] });
    } catch (error) {
      console.error('Warn prefix command error:', error);
      await message.reply('⚠️ An error occurred while issuing the warning!');
    }
  },
};