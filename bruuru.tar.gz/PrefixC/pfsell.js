const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const shopItems = require('../shopItems.js');
const path = './Balance.json';
const invPath = './inventory.json';
const emoji = '<:0_Deco_stargold:1363095379364679881>';

module.exports = {
  name: 'sell',
  description: 'Sell items from your inventory',
  usage: 'sell <item name> <amount>',
  execute(message, args) {
    try {
      if (args.length < 2) {
        return message.reply('Please specify both item name and amount! Usage: `sell <item name> <amount>`');
      }

      const amount = parseInt(args.pop());
      if (isNaN(amount) || amount <= 0) {
        return message.reply('Please provide a valid positive number for amount!');
      }

      const itemName = args.join(' ');
      const item = shopItems.find(i => i.name.toLowerCase() === itemName.toLowerCase());

      if (!item) {
        return message.reply('Invalid item name!');
      }

      let balanceData = fs.existsSync(path) ? JSON.parse(fs.readFileSync(path, 'utf8')) : {};
      let invData = fs.existsSync(invPath) ? JSON.parse(fs.readFileSync(invPath, 'utf8')) : {};

      const userInv = invData[message.author.id] || {};
      if (!userInv[item.name] || userInv[item.name] < amount) {
        return message.reply(`You don't have ${amount} ${item.name} in your inventory!`);
      }

      userInv[item.name] -= amount;
      if (userInv[item.name] === 0) {
        delete userInv[item.name];
      }
      if (Object.keys(userInv).length === 0) {
        delete invData[message.author.id];
      } else {
        invData[message.author.id] = userInv;
      }
      const totalPrice = item.price * amount;
      balanceData[message.author.id] = (balanceData[message.author.id] ?? 0) + totalPrice;

      fs.writeFileSync(path, JSON.stringify(balanceData, null, 2));
      fs.writeFileSync(invPath, JSON.stringify(invData, null, 2));

      const embed = new EmbedBuilder()
        .setColor('#FFD700')
        .setTitle(`${emoji} Sale Successful`)
        .setDescription(`You sold **${amount} ${item.name}** for **${totalPrice.toLocaleString()} Thunder Coins**!`)
        .addFields(
          { name: 'New Balance', value: `${balanceData[message.author.id].toLocaleString()} Thunder Coins`, inline: true }
        )
        .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
        .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() });

      message.channel.send({ embeds: [embed] });
    } catch (error) {
      console.error('Sell prefix command error:', error);
      message.reply('An error occurred!');
    }
  },
};