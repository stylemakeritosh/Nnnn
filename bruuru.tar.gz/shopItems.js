const shopItems = [
  { 
    name: 'Yukimiya Glasses', 
    price: 4000, 
    description: 'nothing special' 
  },
  { 
    name: 'Don Lorenzo Smell', 
    price: 9000, 
    description: 'nothing special' 
  },
  { 
    name: 'Nagi Control', 
    price: 13000, 
    description: 'nothing special' 
  },
  { 
    name: 'Nagi Burger', 
    price: 36000, 
    description: 'hello Japan I am Nagi burgers' 
  },
  { 
    name: 'Metavision', 
    price: 50000, 
    description: '2% chance to get a random item for free (not stackable, need to message).' 
  },
  { 
    name: 'Gimme... M', 
    price: 100000, 
    description: '15% boost to rob command success chance (not stackable).' 
  },
  { 
    name: 'Kaiser Kiss', 
    price: 271000, 
    description: '10% chance to get 10k Thunder Coins (not stackable, need to message).' 
  },
  { 
    name: 'Ego Prime', 
    price: 1499999, 
    description: '15% chance to get 10k Thunder Coins (stackable, need to message).' 
  },
  { 
    name: 'Anri Control', 
    price: 1500000, 
    description: '8% chance to boost rob command (stackable).' 
  },
  { 
    name: 'Aiku Defense', 
    price: 1300000, 
    description: 'Reduces rob success chance against you by 25% (stackable up to 2 times, max 50% reduction).' 
  },
  { 
    name: 'Yo Michael', 
    price: 5000000, 
    description: '15% chance to get a free random item (stackable, need to message).' 
  },
];

module.exports = shopItems;