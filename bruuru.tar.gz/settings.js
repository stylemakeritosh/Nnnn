module.exports = {
  prefix: '?', // Prefix for commands
  status: {
    text: 'FUCK XLZ', // Bot's status message
    type: 'PLAYING', // Options: PLAYING, STREAMING, LISTENING, WATCHING, COMPETING
    status: 'online', // Options: online, idle, dnd, invisible
  },
};